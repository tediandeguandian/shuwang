import { Button } from '@/components/ui/button'
import { CHAPTER_TITLES, LEVELS } from '@/game/levels'
import { RATING } from '@/game/storage'
import { briefEntries } from '@/game/codex'
import type { Progress } from '@/game/types'
import { ArrowLeft, Check, Lock, Play } from 'lucide-react'

type Props = {
  progress: Progress
  /** 玩家已经知道内容的关卡 */
  knownIds: string[]
  onPick: (id: string) => void
  onBack: () => void
}

const CHAPTERS = [1, 2, 3, 4]

export default function LevelSelect({ progress, knownIds, onPick, onBack }: Props) {
  const unlocked = (index: number) => index === 0 || !!progress[LEVELS[index - 1].id]
  const doneCount = LEVELS.filter((l) => progress[l.id]).length

  return (
    <div className="relative min-h-screen w-full">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-[-20%] h-[420px] w-[760px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,196,110,0.07),transparent_68%)] blur-2xl" />
      </div>

      <div className="relative mx-auto w-full max-w-[1120px] px-5 py-8 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Button variant="ghost" className="lc-ghost px-5" onClick={onBack}>
              <ArrowLeft className="mr-2 h-4 w-4" /> 返回
            </Button>
            <div className="lc-label mt-6">关卡目录</div>
            <h1 className="lc-title mt-2 text-4xl">显影过的路</h1>
          </div>
          <div className="lc-panel px-4 py-3 text-right">
            <div className="lc-label">已显影</div>
            <div className="lc-num-lg">
              {doneCount}
              <span className="text-[color:var(--ink-faint)]"> / {LEVELS.length}</span>
            </div>
          </div>
        </div>

        <div className="mt-8 space-y-8 pb-14">
          {CHAPTERS.map((c) => {
            const items = LEVELS.map((l, i) => ({ l, i })).filter(({ l }) => l.chapter === c)
            if (items.length === 0) return null
            return (
              <div key={c}>
                <div className="flex items-center gap-4">
                  <span className="text-[15px] tracking-[0.3em] text-[color:var(--ink)]">
                    {CHAPTER_TITLES[c]}
                  </span>
                  <span className="lc-hr flex-1" />
                  <span className="lc-label">第{['一', '二', '三', '四'][c - 1]}章</span>
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {items.map(({ l, i }) => {
                    const open = unlocked(i)
                    const known = knownIds.includes(l.id)
                    const rec = progress[l.id]
                    return (
                      <button
                        key={l.id}
                        type="button"
                        disabled={!open}
                        onClick={() => open && onPick(l.id)}
                        className={`group relative overflow-hidden rounded-[3px] border p-4 text-left transition-all duration-200 ${
                          open
                            ? 'border-[color:var(--line)] bg-[rgba(255,255,255,0.022)] hover:-translate-y-[2px] hover:border-[rgba(255,207,138,0.34)] hover:bg-[rgba(255,207,138,0.05)]'
                            : 'cursor-not-allowed border-[color:var(--line)] bg-[rgba(255,255,255,0.01)] opacity-45'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="lc-label">
                              {String(i + 1).padStart(2, '0')} ·{' '}
                              {!open
                                ? '未显现'
                                : !known
                                  ? '新登场'
                                  : rec
                                    ? '已显影'
                                    : '待照亮'}
                            </div>
                            <div className="mt-1.5 text-[17px] tracking-[0.18em] text-[color:var(--ink)]">
                              {l.name}
                            </div>
                          </div>
                          <span className="mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded-[3px] border border-[color:var(--line)]">
                            {!open ? (
                              <Lock className="h-3.5 w-3.5 text-[color:var(--ink-faint)]" />
                            ) : rec ? (
                              <Check className="h-4 w-4" style={{ color: RATING[rec.rating].color }} />
                            ) : (
                              <Play className="h-3.5 w-3.5 text-[color:var(--warm)]" />
                            )}
                          </span>
                        </div>

                        {open ? (
                          <p className="mt-3 line-clamp-2 text-[12.5px] leading-[1.9] text-[color:var(--ink-dim)]">
                            {l.hint}
                          </p>
                        ) : (
                          <p className="mt-3 text-[12.5px] leading-[1.9] text-[color:var(--ink-faint)]">
                            还没有显现。先走完前面的路。
                          </p>
                        )}

                        {open &&
                          (() => {
                            const entries = briefEntries(l.id)
                            if (entries.length === 0) return null
                            // 还没亲自见过时只给数量预告，机制名要等她走到那里才亮
                            if (!known) {
                              return (
                                <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                                  <span className="text-[10px] tracking-[0.2em] text-[color:var(--warm)]">
                                    即将登场
                                  </span>
                                  <span className="rounded-[2px] border border-dashed border-[rgba(255,207,138,0.35)] px-1.5 py-[1px] text-[10px] tracking-[0.12em] text-[color:var(--warm)]">
                                    ? × {entries.length}
                                  </span>
                                </div>
                              )
                            }
                            return (
                              <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                                <span className="text-[10px] tracking-[0.2em] text-[color:var(--ink-faint)]">
                                  新登场
                                </span>
                                {entries.map((e) => (
                                  <span
                                    key={e.key}
                                    className={`rounded-[2px] border px-1.5 py-[1px] text-[10px] tracking-[0.12em] ${
                                      e.kind === 'hazard'
                                        ? 'border-[rgba(255,106,51,0.4)] text-[#ff9b6a]'
                                        : 'border-[color:var(--line)] text-[color:var(--ink-dim)]'
                                    }`}
                                  >
                                    {e.name}
                                  </span>
                                ))}
                              </div>
                            )
                          })()}

                        <div className="mt-3 flex items-center justify-between">
                          <span className="text-[11px] tracking-[0.2em] text-[color:var(--ink-faint)]">
                            目标光耗 {l.par}
                          </span>
                          {rec && (
                            <span
                              className="text-[12px] tracking-[0.24em]"
                              style={{ color: RATING[rec.rating].color }}
                            >
                              {RATING[rec.rating].name}
                            </span>
                          )}
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
