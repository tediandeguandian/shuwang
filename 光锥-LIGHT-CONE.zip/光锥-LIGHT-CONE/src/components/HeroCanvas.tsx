import { useEffect, useRef } from 'react'
import { boil, clamp, hatch, rectPts, sketchPath } from '@/game/sketch'
import type { Pt } from '@/game/sketch'

const W = 1280
const H = 430
const LANE = 330

type Plat = { x: number; w: number; paper: boolean }

const PLATS: Plat[] = [
  { x: -40, w: 340, paper: false },
  { x: 300, w: 350, paper: true },
  { x: 650, w: 230, paper: false },
  { x: 880, w: 320, paper: true },
  { x: 1200, w: 220, paper: false },
]

export default function HeroCanvas() {
  const ref = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = Math.round(W * dpr)
    canvas.height = Math.round(H * dpr)

    const pointer = { x: W * 0.5, y: LANE - 90, active: false }
    const lastLit = PLATS.map(() => -99)
    let fig = 30
    let figAlpha = 1
    let waiting = 0
    let t = 0
    let raf = 0
    let last = performance.now()

    const move = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect()
      pointer.x = ((e.clientX - rect.left) / rect.width) * W
      pointer.y = ((e.clientY - rect.top) / rect.height) * H
      pointer.active = true
    }
    canvas.addEventListener('pointermove', move)

    const lit = (p: Plat, radius: number) => {
      const px = clamp(pointer.x, p.x, p.x + p.w)
      const d = Math.hypot(px - pointer.x, LANE - pointer.y)
      return d <= radius
    }

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop)
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      t += dt
      const step = boil(t)
      const radius = 190

      if (!pointer.active) {
        pointer.x = W * 0.5 + Math.sin(t * 0.32) * 310
        pointer.y = LANE - 80 + Math.sin(t * 0.47) * 34
      }

      const solid = (x: number) =>
        PLATS.some(
          (p, i) =>
            x >= p.x &&
            x <= p.x + p.w &&
            (!p.paper || lit(p, radius) || t - lastLit[i] < 1.2),
        )

      const next = fig + 80 * dt
      if (next > 1258) {
        figAlpha -= dt * 1.4
        if (figAlpha <= 0) {
          fig = 30
          figAlpha = 1
        }
      } else if (solid(next + 14)) {
        fig = next
        waiting = Math.max(0, waiting - dt)
      } else {
        waiting += dt
      }

      PLATS.forEach((p, i) => {
        if (p.paper && lit(p, radius)) lastLit[i] = t
      })

      /* ── 绘制 ── */
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, W, H)
      const bg = ctx.createLinearGradient(0, 0, 0, H)
      bg.addColorStop(0, '#08080a')
      bg.addColorStop(1, '#0b0b0e')
      ctx.fillStyle = bg
      ctx.fillRect(0, 0, W, H)

      // 远景剪影
      for (let i = 0; i < 9; i++) {
        const x = i * 170 - 60
        const h = 60 + ((i * 37) % 90)
        const pts: Pt[] = [
          { x, y: LANE },
          { x: x + 26, y: LANE - h },
          { x: x + 74, y: LANE - h * 0.55 },
          { x: x + 120, y: LANE },
        ]
        ctx.fillStyle = 'rgba(255,252,244,0.012)'
        sketchPath(ctx, pts, i * 3.1, step, 2.4, true)
        ctx.fill()
        ctx.strokeStyle = 'rgba(226,220,208,0.045)'
        ctx.lineWidth = 1.4
        ctx.stroke()
      }

      // 平台
      PLATS.forEach((p, i) => {
        const isLit = p.paper && lit(p, radius)
        const remain = clamp(1 - (t - lastLit[i]) / 1.2, 0, 1)
        const solidNow = !p.paper || isLit || remain > 0
        const rect = { x: p.x, y: LANE, w: p.w, h: H - LANE }
        if (!solidNow) {
          ctx.save()
          ctx.setLineDash([6, 9])
          ctx.strokeStyle = 'rgba(206,196,172,0.09)'
          ctx.lineWidth = 1.1
          sketchPath(ctx, rectPts(rect), i * 5.2, step, 1.4, true)
          ctx.stroke()
          ctx.restore()
          return
        }
        const k = isLit ? 1 : remain
        ctx.save()
        ctx.globalAlpha = p.paper ? 0.32 + k * 0.68 : 1
        sketchPath(ctx, rectPts(rect), i * 5.2, step, 1.6, true)
        ctx.fillStyle = p.paper ? (isLit ? '#ece3cf' : '#c9a468') : '#131317'
        ctx.fill()
        ctx.save()
        ctx.globalAlpha *= 0.5
        ctx.strokeStyle = p.paper && isLit ? '#3b3529' : '#22222a'
        ctx.lineWidth = 1
        hatch(ctx, { x: rect.x, y: rect.y, w: rect.w, h: 90 }, i * 5.2 + 2, step, 16, 1.4, 70)
        ctx.restore()
        ctx.lineWidth = 2
        ctx.strokeStyle = p.paper ? (isLit ? '#1d1a15' : '#7a5f34') : '#3a3a43'
        ctx.stroke()
        ctx.restore()
      })

      // 小人
      const moving = solid(fig + 14)
      const swing = moving ? Math.sin(t * 7) : 0
      const bob = moving ? Math.abs(Math.sin(t * 7)) * 1.7 : Math.sin(t * 1.6) * 0.9
      const cx = fig
      const hy = LANE - 46 + bob
      ctx.save()
      ctx.globalAlpha = Math.max(0, figAlpha)
      ctx.lineWidth = 2.6
      ctx.lineCap = 'round'
      ctx.strokeStyle = '#f2ead8'
      ctx.beginPath()
      ctx.ellipse(cx, hy + 8, 6.4, 6.9, 0, 0, Math.PI * 2)
      ctx.stroke()
      ctx.beginPath()
      ctx.moveTo(cx, hy + 15)
      ctx.lineTo(cx + swing * 1.2, hy + 31)
      ctx.stroke()
      for (const s of [-1, 1]) {
        sketchPath(
          ctx,
          [
            { x: cx + swing * 1.2, y: hy + 31 },
            { x: cx + swing * 7 * s + 2 * s, y: LANE - 1 },
          ],
          5.5,
          step,
          0.9,
          false,
        )
        ctx.stroke()
      }
      ctx.restore()

      // 光锥
      const grad = ctx.createRadialGradient(pointer.x, pointer.y, 0, pointer.x, pointer.y, radius * 1.2)
      grad.addColorStop(0, 'rgba(255,226,175,0.34)')
      grad.addColorStop(0.34, 'rgba(255,203,124,0.19)')
      grad.addColorStop(0.72, 'rgba(255,176,88,0.075)')
      grad.addColorStop(1, 'rgba(255,160,70,0)')
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      ctx.fillStyle = grad
      ctx.fillRect(pointer.x - radius * 1.3, pointer.y - radius * 1.3, radius * 2.6, radius * 2.6)
      ctx.restore()

      // 黑暗
      const dark = ctx.createRadialGradient(
        pointer.x,
        pointer.y,
        radius * 0.6,
        pointer.x,
        pointer.y,
        radius * 2.6,
      )
      dark.addColorStop(0, 'rgba(6,6,8,0)')
      dark.addColorStop(0.45, 'rgba(6,6,8,0.3)')
      dark.addColorStop(1, 'rgba(6,6,8,0.88)')
      ctx.fillStyle = dark
      ctx.fillRect(0, 0, W, H)

      // 暗角
      const vig = ctx.createRadialGradient(W / 2, H / 2, H * 0.32, W / 2, H / 2, H * 1.05)
      vig.addColorStop(0, 'rgba(0,0,0,0)')
      vig.addColorStop(1, 'rgba(0,0,0,0.66)')
      ctx.fillStyle = vig
      ctx.fillRect(0, 0, W, H)

      // 提示语
      if (waiting > 0.8) {
        ctx.save()
        ctx.globalAlpha = Math.min(0.7, (waiting - 0.8) * 0.6)
        ctx.textAlign = 'center'
        ctx.fillStyle = '#ffcf8a'
        ctx.font = '400 16px "Noto Serif SC","Songti SC",serif'
        ctx.fillText('它在等你照亮前面的路', W / 2, H - 36)
        ctx.restore()
      }
    }

    raf = requestAnimationFrame(loop)
    return () => {
      cancelAnimationFrame(raf)
      canvas.removeEventListener('pointermove', move)
    }
  }, [])

  return (
    <canvas
      ref={ref}
      className="h-full w-full cursor-crosshair touch-none select-none"
      aria-label="演示：移动指针照亮断桥"
    />
  )
}
