import { useEffect, useRef } from 'react'
import { PALETTE as P } from '@/game/palette'
import { boil, hatch, rectPts, sketchPath } from '@/game/sketch'
import type { Pt } from '@/game/sketch'
import type { CodexKey } from '@/game/codex'

/* 所有图标都画在 100×100 的坐标系内，沿用游戏里的手绘炭笔风格 */

const ground = (ctx: CanvasRenderingContext2D, step: number, y = 80) => {
  ctx.save()
  sketchPath(ctx, [{ x: 4, y }, { x: 96, y }], 3.1, step, 1.1, false)
  ctx.strokeStyle = P.stoneEdge
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.restore()
}

const cone = (ctx: CanvasRenderingContext2D, x: number, y: number, r: number, alpha = 1) => {
  ctx.save()
  ctx.globalCompositeOperation = 'lighter'
  const g = ctx.createRadialGradient(x, y, 0, x, y, r)
  g.addColorStop(0, `rgba(255,230,185,${0.4 * alpha})`)
  g.addColorStop(0.45, `rgba(255,205,130,${0.2 * alpha})`)
  g.addColorStop(1, 'rgba(255,170,80,0)')
  ctx.fillStyle = g
  ctx.fillRect(x - r, y - r, r * 2, r * 2)
  ctx.restore()
}

const paperRect = (
  ctx: CanvasRenderingContext2D,
  r: { x: number; y: number; w: number; h: number },
  seed: number,
  step: number,
  alpha = 1,
  tone: 'lit' | 'fade' = 'lit',
) => {
  ctx.save()
  ctx.globalAlpha = alpha
  sketchPath(ctx, rectPts(r), seed, step, 1.4, true)
  ctx.fillStyle = tone === 'lit' ? P.paperLit : P.after
  ctx.fill()
  ctx.save()
  ctx.globalAlpha = alpha * 0.5
  ctx.strokeStyle = tone === 'lit' ? P.paperLitHatch : P.afterHatch
  ctx.lineWidth = 1
  hatch(ctx, r, seed + 2.2, step, 9, 1.1, 60)
  ctx.restore()
  ctx.lineWidth = 1.8
  ctx.strokeStyle = tone === 'lit' ? P.paperLitEdge : P.afterEdge
  ctx.stroke()
  ctx.restore()
}

const dashRect = (
  ctx: CanvasRenderingContext2D,
  r: { x: number; y: number; w: number; h: number },
  seed: number,
  step: number,
) => {
  ctx.save()
  ctx.setLineDash([4, 5])
  ctx.strokeStyle = 'rgba(206,196,172,0.42)'
  ctx.lineWidth = 1.3
  sketchPath(ctx, rectPts(r), seed, step, 1.2, true)
  ctx.stroke()
  ctx.restore()
}

const figure = (
  ctx: CanvasRenderingContext2D,
  x: number,
  feetY: number,
  t: number,
  walk = true,
  color = P.char,
) => {
  const swing = walk ? Math.sin(t * 6) : 0
  const bob = walk ? Math.abs(Math.sin(t * 6)) * 1.2 : 0
  const hy = feetY - 30 + bob
  ctx.save()
  ctx.strokeStyle = color
  ctx.lineWidth = 2
  ctx.lineCap = 'round'
  ctx.beginPath()
  ctx.ellipse(x, hy + 5, 4, 4.3, 0, 0, Math.PI * 2)
  ctx.stroke()
  ctx.beginPath()
  ctx.moveTo(x, hy + 9)
  ctx.lineTo(x + swing, hy + 20)
  ctx.stroke()
  ctx.beginPath()
  ctx.moveTo(x + swing, hy + 20)
  ctx.lineTo(x - swing * 4 - 1.5, feetY)
  ctx.moveTo(x + swing, hy + 20)
  ctx.lineTo(x + swing * 4 + 1.5, feetY)
  ctx.stroke()
  ctx.restore()
}

const inkBlob = (ctx: CanvasRenderingContext2D, cx: number, baseY: number, t: number, step: number) => {
  const h = 26 + Math.sin(t * 3) * 1.6
  const top = baseY - h
  ctx.save()
  const pts: Pt[] = [
    { x: cx - 14, y: baseY },
    { x: cx - 12, y: top + h * 0.3 },
    { x: cx - 6, y: top },
    { x: cx + 7, y: top + h * 0.14 },
    { x: cx + 14, y: top + h * 0.44 },
    { x: cx + 13, y: baseY },
  ]
  sketchPath(ctx, pts, 7.7, step, 2, true)
  ctx.fillStyle = P.ink
  ctx.fill()
  ctx.lineWidth = 1.6
  ctx.strokeStyle = '#2b2118'
  ctx.stroke()
  const blink = Math.sin(t * 2.4) > -0.85 ? 1 : 0.18
  ctx.fillStyle = P.eye
  for (const s of [-1, 1]) {
    ctx.beginPath()
    ctx.ellipse(cx + s * 5, top + h * 0.36, 3, 1.8 * blink, 0, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.globalAlpha = 0.3
  ctx.beginPath()
  ctx.ellipse(cx, top + h * 0.36, 16, 8, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()
}

const watcherFigure = (
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  t: number,
  step: number,
  papered: boolean,
) => {
  const h = 34
  const lean = papered ? 0 : Math.sin(t * 7) * 1.6
  ctx.save()
  const pts: Pt[] = [
    { x: cx - 8, y: baseY },
    { x: cx - 7 + lean, y: baseY - h * 0.55 },
    { x: cx - 4 + lean * 1.3, y: baseY - h },
    { x: cx + 4 + lean, y: baseY - h * 1.02 },
    { x: cx + 8, y: baseY - h * 0.5 },
    { x: cx + 8, y: baseY },
  ]
  sketchPath(ctx, pts, 12.3, step, 1.8, true)
  if (papered) {
    ctx.fillStyle = 'rgba(236,227,207,0.92)'
    ctx.fill()
    ctx.save()
    ctx.globalAlpha = 0.45
    ctx.strokeStyle = P.paperLitHatch
    ctx.lineWidth = 1
    hatch(ctx, { x: cx - 10, y: baseY - h, w: 20, h }, 12.3, step, 6, 1, 74)
    ctx.restore()
    ctx.strokeStyle = P.coldDeep
    ctx.lineWidth = 1.8
  } else {
    ctx.fillStyle = 'rgba(16,20,26,0.94)'
    ctx.fill()
    ctx.strokeStyle = P.cold
    ctx.lineWidth = 1.5
  }
  ctx.stroke()
  ctx.beginPath()
  ctx.moveTo(cx - 5, baseY - h * 0.78)
  ctx.lineTo(cx + 5, baseY - h * 0.78)
  ctx.lineWidth = 2
  ctx.strokeStyle = papered ? '#5d7387' : P.coldDeep
  ctx.stroke()
  ctx.restore()
}

export const drawGlyph = (
  ctx: CanvasRenderingContext2D,
  kind: CodexKey,
  t: number,
  step: number,
) => {
  switch (kind) {
    case 'her': {
      ground(ctx, step, 82)
      cone(ctx, 26, 40, 34, 0.9)
      figure(ctx, 56, 82, t, true)
      // 向前的箭头
      ctx.save()
      ctx.strokeStyle = 'rgba(255,207,138,0.75)'
      ctx.lineWidth = 1.8
      ctx.beginPath()
      ctx.moveTo(72, 62)
      ctx.lineTo(90, 62)
      ctx.moveTo(85, 57)
      ctx.lineTo(90, 62)
      ctx.lineTo(85, 67)
      ctx.stroke()
      ctx.restore()
      break
    }
    case 'paper': {
      dashRect(ctx, { x: 10, y: 50, w: 30, h: 26 }, 1.1, step)
      paperRect(ctx, { x: 48, y: 50, w: 40, h: 26 }, 4.4, step)
      cone(ctx, 68, 40, 34)
      break
    }
    case 'stone': {
      ground(ctx, step, 82)
      const r = { x: 12, y: 48, w: 76, h: 34 }
      ctx.save()
      sketchPath(ctx, rectPts(r), 2.7, step, 1.2, true)
      ctx.fillStyle = P.stoneFill
      ctx.fill()
      ctx.lineWidth = 2
      ctx.strokeStyle = P.stoneEdge
      ctx.stroke()
      ctx.globalAlpha = 0.6
      ctx.strokeStyle = P.stoneHatch
      ctx.lineWidth = 1
      hatch(ctx, r, 9.2, step, 11, 1.1, 74)
      ctx.restore()
      break
    }
    case 'wall': {
      ground(ctx, step, 82)
      const w = { x: 54, y: 24, w: 12, h: 58 }
      cone(ctx, 60, 44, 32)
      paperRect(ctx, w, 5.9, step)
      figure(ctx, 30, 82, t, false)
      // 被挡住的小标记
      ctx.save()
      ctx.strokeStyle = P.warm
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(40, 50)
      ctx.lineTo(46, 50)
      ctx.moveTo(40, 56)
      ctx.lineTo(46, 56)
      ctx.stroke()
      ctx.restore()
      break
    }
    case 'afterimage': {
      paperRect(ctx, { x: 8, y: 46, w: 24, h: 24 }, 3.3, step)
      cone(ctx, 20, 36, 22)
      paperRect(ctx, { x: 38, y: 46, w: 24, h: 24 }, 6.6, step, 0.5, 'fade')
      dashRect(ctx, { x: 68, y: 46, w: 24, h: 24 }, 8.8, step)
      ctx.save()
      ctx.strokeStyle = 'rgba(255,207,138,0.5)'
      ctx.lineWidth = 1.4
      ctx.beginPath()
      ctx.moveTo(20, 78)
      ctx.lineTo(80, 78)
      ctx.stroke()
      for (const x of [20, 50, 80]) {
        ctx.beginPath()
        ctx.arc(x, 78, 2, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(255,207,138,0.6)'
        ctx.fill()
      }
      ctx.restore()
      break
    }
    case 'eater': {
      ground(ctx, step, 82)
      const r = { x: 8, y: 62, w: 84, h: 20 }
      ctx.save()
      ctx.fillStyle = P.stoneFill
      sketchPath(ctx, rectPts(r), 2.2, step, 1.1, true)
      ctx.fill()
      ctx.strokeStyle = P.stoneEdge
      ctx.lineWidth = 1.6
      ctx.stroke()
      ctx.restore()
      cone(ctx, 50, 46, 36)
      inkBlob(ctx, 50, 62, t, step)
      break
    }
    case 'energy': {
      ctx.save()
      // 光环电量
      ctx.lineWidth = 3
      ctx.strokeStyle = 'rgba(220,210,190,0.16)'
      ctx.beginPath()
      ctx.arc(50, 50, 32, -Math.PI * 0.5, Math.PI * 1.5)
      ctx.stroke()
      ctx.strokeStyle = P.warm
      ctx.beginPath()
      ctx.arc(50, 50, 32, -Math.PI * 0.5, -Math.PI * 0.5 + Math.PI * 1.06)
      ctx.stroke()
      // 闭着的眼
      ctx.beginPath()
      ctx.moveTo(36, 50)
      ctx.quadraticCurveTo(50, 60, 64, 50)
      ctx.lineWidth = 2.2
      ctx.strokeStyle = P.char
      ctx.stroke()
      ctx.beginPath()
      for (let i = -2; i <= 2; i++) {
        ctx.moveTo(50 + i * 6, 55)
        ctx.lineTo(50 + i * 6.6, 60)
      }
      ctx.lineWidth = 1.2
      ctx.strokeStyle = 'rgba(242,234,216,0.5)'
      ctx.stroke()
      ctx.restore()
      break
    }
    case 'watcher': {
      ground(ctx, step, 82)
      watcherFigure(ctx, 26, 82, t, step, false)
      cone(ctx, 74, 46, 30)
      watcherFigure(ctx, 74, 82, t, step, true)
      break
    }
    case 'door': {
      const frame = { x: 26, y: 20, w: 48, h: 60 }
      ctx.save()
      ctx.lineWidth = 2.4
      ctx.strokeStyle = P.stoneEdge
      sketchPath(ctx, rectPts(frame), 31.3, step, 1.6, true)
      ctx.stroke()
      // 左半：砌死的砖
      ctx.save()
      ctx.beginPath()
      ctx.rect(26, 20, 24, 60)
      ctx.clip()
      ctx.strokeStyle = 'rgba(150,142,126,0.75)'
      ctx.lineWidth = 1.3
      for (let i = 1; i < 5; i++) {
        ctx.beginPath()
        ctx.moveTo(26, 20 + i * 12)
        ctx.lineTo(50, 20 + i * 12)
        ctx.stroke()
      }
      for (let i = 0; i < 6; i++) {
        ctx.beginPath()
        ctx.moveTo(26 + i * 8, 20)
        ctx.lineTo(28 + i * 8, 80)
        ctx.stroke()
      }
      ctx.restore()
      // 右半：黑暗里打开的门
      ctx.save()
      ctx.beginPath()
      ctx.rect(50, 20, 24, 60)
      ctx.clip()
      ctx.globalCompositeOperation = 'lighter'
      const g = ctx.createLinearGradient(50, 20, 74, 80)
      g.addColorStop(0, 'rgba(255,214,150,0.5)')
      g.addColorStop(1, 'rgba(255,168,90,0.12)')
      ctx.fillStyle = g
      ctx.fillRect(50, 20, 24, 60)
      ctx.restore()
      ctx.restore()
      break
    }
  }
}

export default function CodexGlyph({ kind, size = 76 }: { kind: CodexKey; size?: number }) {
  const ref = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = Math.round(100 * dpr)
    canvas.height = Math.round(100 * dpr)
    let raf = 0
    let t = 0
    let last = performance.now()
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop)
      t += Math.min(0.05, (now - last) / 1000)
      last = now
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, 100, 100)
      drawGlyph(ctx, kind, t, boil(t))
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [kind])

  return (
    <canvas
      ref={ref}
      style={{ width: size, height: size }}
      className="flex-none rounded-[3px] border border-[color:var(--line)] bg-[rgba(255,255,255,0.02)]"
      aria-hidden
    />
  )
}
