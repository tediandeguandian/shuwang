import CodexGlyph from './CodexGlyph'
import { Button } from '@/components/ui/button'
import { KIND_LABEL } from '@/game/codex'
import type { CodexEntry } from '@/game/codex'
import { X } from 'lucide-react'

const KIND_STYLE: Record<string, string> = {
  rule: 'border-[rgba(214,204,182,0.28)] text-[color:var(--ink-dim)]',
  tool: 'border-[rgba(255,207,138,0.4)] text-[color:var(--warm)]',
  hazard: 'border-[rgba(255,106,51,0.45)] text-[#ff9b6a]',
}

export type CodexOverlayProps = {
  title: string
  subtitle?: string
  entries: CodexEntry[]
  primaryLabel: string
  onPrimary: () => void
  secondaryLabel?: string
  onSecondary?: () => void
  columns?: 1 | 2
}

export default function CodexOverlay({
  title,
  subtitle,
  entries,
  primaryLabel,
  onPrimary,
  secondaryLabel,
  onSecondary,
  columns = 2,
}: CodexOverlayProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[rgba(6,6,8,0.88)] p-3 backdrop-blur-[3px] sm:p-6">
      <div className="lc-panel flex max-h-full w-[min(96%,880px)] flex-col overflow-hidden">
        <header className="flex items-start justify-between gap-4 border-b border-[color:var(--line)] px-5 py-4 sm:px-6">
          <div>
            {subtitle && <div className="lc-label">{subtitle}</div>}
            <h2 className="lc-title mt-1 text-2xl">{title}</h2>
          </div>
          {onSecondary && secondaryLabel && (
            <Button variant="ghost" size="icon" className="lc-btn" onClick={onSecondary} aria-label="关闭">
              <X className="h-4 w-4" />
            </Button>
          )}
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4 sm:px-6 sm:py-5">
          {entries.length === 0 && (
            <div className="rounded-[3px] border border-dashed border-[color:var(--line)] px-4 py-8 text-center text-[13px] leading-[2] text-[color:var(--ink-faint)]">
              还没有任何东西显现。
              <br />
              继续注视，它会在该出现的关卡里自己亮起来。
            </div>
          )}
          <div className={`grid gap-3 ${columns === 2 ? 'md:grid-cols-2' : ''}`}>
            {entries.map((e) => (
              <article
                key={e.key}
                className="flex gap-4 rounded-[3px] border border-[color:var(--line)] bg-[rgba(255,255,255,0.022)] p-3.5"
              >
                <CodexGlyph kind={e.key} size={78} />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                    <span className="text-[16px] tracking-[0.14em] text-[color:var(--ink)]">
                      {e.name}
                    </span>
                    <span className="lc-label">{e.latin}</span>
                    <span
                      className={`rounded-[2px] border px-1.5 py-[1px] text-[10px] tracking-[0.18em] ${
                        KIND_STYLE[e.kind]
                      }`}
                    >
                      {KIND_LABEL[e.kind]}
                    </span>
                  </div>
                  <div className="mt-1.5 text-[13px] tracking-[0.06em] text-[color:var(--warm)]/95">
                    「{e.tagline}」
                  </div>
                  <p className="mt-2 text-[12.5px] leading-[2] text-[color:var(--ink-dim)]">
                    {e.body}
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>

        <footer className="flex flex-wrap items-center justify-end gap-2 border-t border-[color:var(--line)] px-5 py-4 sm:px-6">
          {onSecondary && secondaryLabel && (
            <Button variant="ghost" className="lc-ghost px-5" onClick={onSecondary}>
              {secondaryLabel}
            </Button>
          )}
          <Button className="lc-primary px-7" onClick={onPrimary}>
            {primaryLabel}
          </Button>
        </footer>
      </div>
    </div>
  )
}
