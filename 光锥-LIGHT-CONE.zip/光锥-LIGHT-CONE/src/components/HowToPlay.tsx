import { Button } from '@/components/ui/button'
import { briefEntries } from '@/game/codex'
import type { CodexKey } from '@/game/codex'
import {
  ArrowLeft,
  BatteryCharging,
  Bug,
  EyeOff,
  Focus,
  Ghost,
  Hourglass,
  Keyboard,
  Layers,
  Lock,
  MousePointer2,
  RectangleVertical,
  Sun,
  Target,
} from 'lucide-react'

type Props = {
  /** 玩家已经知道内容的关卡 */
  knownIds: string[]
  onBack: () => void
  onStart: () => void
}

type Rule = {
  icon: typeof Sun
  title: string
  body: string
  /** 需要先在某关见过，才会显现 */
  gate?: CodexKey
}

const RULES: Rule[] = [
  {
    icon: Sun,
    title: '光照亮的地方才存在',
    body: '她脚下的桥是「纸」做的。被光锥覆盖时，纸会实体化；光一离开，桥就散成噪点。她不会停下等你，只会向前走。',
  },
  {
    icon: EyeOff,
    title: '黑暗里什么都不存在——包括危险',
    body: '只在你注视时才成立的东西，也一样。所以最安全的那条路，往往正是你「不看」的那一段。',
  },
  {
    icon: Layers,
    title: '残影会替你多撑一会儿',
    body: '被照亮过的纸，熄灭后还会保留 1.35 秒。高手不会把光放在她脚下，而是提前扫过前方的路。',
    gate: 'afterimage',
  },
  {
    icon: RectangleVertical,
    title: '纸墙：光造出路，也筑起墙',
    body: '立在路中间的纸柱。被照亮时她会撞上去停下；想让她通过，就得把光从它身上移开。',
    gate: 'wall',
  },
  {
    icon: Bug,
    title: '蚀：别把光照在它身上',
    body: '它睡在石地上，只在被照亮时苏醒并咬人。你需要把光停在「两枚蚀之间的窄缝」里。',
    gate: 'eater',
  },
  {
    icon: Ghost,
    title: '逆视者：你不看它，它就来抓她',
    body: '它的规则和蚀正好相反：被注视时它会被压成一张纸，直接穿过去就行；可你一移开视线，它重新变成实体，并朝她走来。',
    gate: 'watcher',
  },
  {
    icon: BatteryCharging,
    title: '光会耗尽，闭眼就是呼吸',
    body: '第三、四章有光能上限。按住空格闭眼，光能在黑暗里恢复；闭眼时世界是真的全黑，你需要相信她。',
    gate: 'energy',
  },
]

const KEYS = [
  { icon: MousePointer2, k: '鼠标移动 / WASD / 方向键', v: '移动光锥' },
  { icon: Focus, k: '滚轮 / Q · E', v: '调焦：窄而亮，或宽而暗' },
  { icon: EyeOff, k: '按住空格', v: '闭眼（光锥熄灭，恢复光能）' },
  { icon: Keyboard, k: '按住 Tab', v: '显示蓝图：看见整关的草图' },
  { icon: Hourglass, k: 'Esc / P · R', v: '暂停 · 重来本关' },
]

export default function HowToPlay({ knownIds, onBack, onStart }: Props) {
  /** 只有已经接触过的机制会显现，没解锁的章节不会被提前剧透 */
  const revealed = new Set<string>()
  for (const id of knownIds) for (const e of briefEntries(id)) revealed.add(e.key)
  const shown = RULES.filter((r) => !r.gate || revealed.has(r.gate)).length

  return (
    <div className="relative min-h-screen w-full">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-[-24%] h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,196,110,0.07),transparent_68%)] blur-2xl" />
      </div>

      <div className="relative mx-auto w-full max-w-[1060px] px-5 py-8 sm:px-8">
        <Button variant="ghost" className="lc-ghost px-5" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" /> 返回
        </Button>

        <div className="mt-8">
          <div className="lc-label">
            规则 · 已显现 {shown}/{RULES.length} 条
          </div>
          <h1 className="lc-title mt-2 text-4xl">玩法说明</h1>
          <p className="mt-3 max-w-[620px] text-[14px] leading-[2] text-[color:var(--ink-dim)]">
            这是一个把「观察」本身做成玩法的游戏。你的操作只有一个动词：看。
            但看有代价——你照亮的地方会存在，也会醒来。
          </p>
          <p className="mt-3 max-w-[620px] text-[13px] leading-[2] text-[color:var(--warm)]/85">
            每当有新东西登场，关卡开场会自动弹出说明卡片。下面这些卡片会随着你的进度一条条显现——
            还没走到的地方，就先让它暗着。游玩中随时点右上角的书本按钮，可以调出已经显现的机制图鉴。
          </p>
        </div>

        <div className="lc-hr my-8" />

        <div className="grid gap-3 md:grid-cols-2">
          {RULES.map((r) => {
            const open = !r.gate || revealed.has(r.gate)
            if (!open) {
              return (
                <div
                  key={r.title}
                  className="rounded-[3px] border border-dashed border-[color:var(--line)] bg-[rgba(255,255,255,0.012)] p-4"
                >
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded-[3px] border border-dashed border-[color:var(--line)]">
                      <Lock className="h-3.5 w-3.5 text-[color:var(--ink-faint)]" />
                    </span>
                    <div>
                      <div className="text-[15px] tracking-[0.12em] text-[color:var(--ink-faint)]">
                        未显现
                      </div>
                      <p className="mt-1.5 text-[13px] leading-[1.95] text-[color:var(--ink-faint)]">
                        继续注视。它会在该出现的关卡里自己亮起来。
                      </p>
                    </div>
                  </div>
                </div>
              )
            }
            return (
              <div key={r.title} className="lc-card">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-8 w-8 flex-none items-center justify-center rounded-[3px] border border-[color:var(--line)] bg-[rgba(255,207,138,0.06)]">
                    <r.icon className="h-4 w-4 text-[color:var(--warm)]" />
                  </span>
                  <div>
                    <div className="text-[15px] tracking-[0.1em] text-[color:var(--ink)]">
                      {r.title}
                    </div>
                    <p className="mt-1.5 text-[13px] leading-[1.95] text-[color:var(--ink-dim)]">
                      {r.body}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        <div className="lc-hr my-8" />

        <div className="grid gap-6 md:grid-cols-[1.15fr_1fr]">
          <div>
            <div className="lc-label">操作</div>
            <div className="mt-3 space-y-2">
              {KEYS.map((k) => (
                <div
                  key={k.k}
                  className="flex items-center justify-between gap-4 rounded-[3px] border border-[color:var(--line)] bg-[rgba(255,255,255,0.02)] px-3 py-2.5"
                >
                  <span className="flex items-center gap-2.5 text-[13px] text-[color:var(--ink)]">
                    <k.icon className="h-4 w-4 text-[color:var(--warm)]" />
                    {k.k}
                  </span>
                  <span className="text-[12px] text-[color:var(--ink-dim)]">{k.v}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="lc-label">评价</div>
            <div className="mt-3 space-y-2">
              <div className="lc-card flex items-center gap-3">
                <Target className="h-4 w-4 text-[#ffcf8a]" />
                <div>
                  <div className="text-[14px] tracking-[0.2em] text-[#ffcf8a]">全蚀</div>
                  <div className="mt-0.5 text-[12px] text-[color:var(--ink-dim)]">
                    光耗低于目标的 72%——你只在必须的时候睁开眼
                  </div>
                </div>
              </div>
              <div className="lc-card flex items-center gap-3">
                <Target className="h-4 w-4 text-[#cfc4ac]" />
                <div>
                  <div className="text-[14px] tracking-[0.2em] text-[#cfc4ac]">半明</div>
                  <div className="mt-0.5 text-[12px] text-[color:var(--ink-dim)]">
                    光耗不超过目标——用得恰到好处
                  </div>
                </div>
              </div>
              <div className="lc-card flex items-center gap-3">
                <Target className="h-4 w-4 text-[#8d8676]" />
                <div>
                  <div className="text-[14px] tracking-[0.2em] text-[#8d8676]">微光</div>
                  <div className="mt-0.5 text-[12px] text-[color:var(--ink-dim)]">
                    完成了，但光烧得有点多
                  </div>
                </div>
              </div>
            </div>
            <p className="mt-4 text-[12px] leading-[1.9] text-[color:var(--ink-faint)]">
              光耗 = 光锥开启时长的加权积分。窄光更便宜，闭眼不花钱。
              每一次失误都会从最近的存档点重来，不会让你从头开始。
            </p>
          </div>
        </div>

        <div className="lc-hr my-8" />

        <div className="flex flex-col items-center gap-4 pb-10 text-center">
          <p className="text-[13px] italic leading-[2] text-[color:var(--warm)]/85">
            「你照亮的世界才存在。但你不看的时候，它也在。」
          </p>
          <Button className="lc-primary px-10" onClick={onStart}>
            开始注视
          </Button>
        </div>
      </div>
    </div>
  )
}
