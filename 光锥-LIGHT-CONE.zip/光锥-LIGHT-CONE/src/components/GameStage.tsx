import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { PointerEvent as ReactPointerEvent } from 'react'
import { Game, VIEW_H, VIEW_W } from '@/game/engine'
import { Renderer } from '@/game/render'
import { audio } from '@/game/audio'
import { LEVELS, nextLevelId } from '@/game/levels'
import { RATING, ratingOf } from '@/game/storage'
import { briefEntries, codexFor } from '@/game/codex'
import type { LevelRecord, Rating } from '@/game/types'
import CodexOverlay from './CodexOverlay'
import { Button } from '@/components/ui/button'
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  EyeOff,
  Focus,
  Footprints,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react'

type Props = {
  levelId: string
  muted: boolean
  /** 玩家已经知道内容的关卡（读过说明或已通关） */
  knownIds: string[]
  onToggleMute: () => void
  onExit: () => void
  onComplete: (id: string, rec: LevelRecord) => void
  onGoLevel: (id: string) => void
  onBriefSeen: (id: string) => void
}

type Hud = {
  time: number
  cost: number
  energy: number
  hasEnergy: boolean
  radius: number
  closed: boolean
  forcedOff: boolean
  status: string
  deaths: number
  holding: boolean
}

const levelIndexOf = (id: string) => LEVELS.findIndex((l) => l.id === id)

export default function GameStage({
  levelId,
  muted,
  onToggleMute,
  onExit,
  onComplete,
  onGoLevel,
  onBriefSeen,
  knownIds,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const gameRef = useRef<Game | null>(null)
  const cbRef = useRef({ onComplete })
  const keysRef = useRef<Set<string>>(new Set())
  /** 最后一次已知的指针位置（画布坐标）：进关卡时用它初始化瞄准点 */
  const pointerRef = useRef<{ x: number; y: number } | null>(null)
  const blueprintRef = useRef(false)
  const finishedRef = useRef(false)
  const imprintRef = useRef(0)
  /** 弹窗（章节说明 / 图鉴）打开时冻结模拟 */
  const freezeRef = useRef(false)
  /** 当前弹窗的确认动作 */
  const dismissRef = useRef<() => void>(() => {})

  const [hud, setHud] = useState<Hud>({
    time: 0,
    cost: 0,
    energy: 1,
    hasEnergy: false,
    radius: 185,
    closed: false,
    forcedOff: false,
    status: 'intro',
    deaths: 0,
    holding: false,
  })
  const [paused, setPaused] = useState(false)
  const [finished, setFinished] = useState<{ rating: Rating; rec: LevelRecord } | null>(null)
  const [coarse] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches,
  )
  /** 本关新登场的机制 */
  const brief = useMemo(() => briefEntries(levelId), [levelId])
  /** 图鉴只列出玩家已经接触过的机制，没解锁的章节不会提前出现 */
  const seenCodex = useMemo(() => codexFor(knownIds), [knownIds])
  const [showBrief, setShowBrief] = useState(() => brief.length > 0 && !knownIds.includes(levelId))
  const [showCodex, setShowCodex] = useState(false)
  freezeRef.current = showBrief || showCodex

  cbRef.current.onComplete = onComplete

  const restart = useCallback(() => {
    const lv = LEVELS[levelIndexOf(levelId)]
    if (!lv) return
    const g = new Game(lv)
    const p = pointerRef.current
    if (p) g.setPointerScreen(p.x, p.y)
    gameRef.current = g
    finishedRef.current = false
    setFinished(null)
    setPaused(false)
  }, [levelId])

  const dismissBrief = useCallback(() => {
    setShowBrief(false)
    onBriefSeen(levelId)
    const g = gameRef.current
    if (g) {
      g.skipIntro()
      g.hold(1.8)
    }
  }, [levelId, onBriefSeen])

  // 切换关卡时重算「首次登场说明」（组件不会重新挂载）
  const knownRef = useRef(knownIds)
  knownRef.current = knownIds
  useEffect(() => {
    setShowBrief(brief.length > 0 && !knownRef.current.includes(levelId))
    setShowCodex(false)
    setPaused(false)
    setFinished(null)
  }, [levelId, brief.length])

  useEffect(() => {
    const lv = LEVELS[levelIndexOf(levelId)]
    const canvas = canvasRef.current
    if (!lv || !canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = Math.round(VIEW_W * dpr)
    canvas.height = Math.round(VIEW_H * dpr)

    const renderer = new Renderer()
    gameRef.current = new Game(lv)
    // 光一开局就落在鼠标上，而不是默认的某个位置
    if (pointerRef.current) {
      gameRef.current.setPointerScreen(pointerRef.current.x, pointerRef.current.y)
    }
    finishedRef.current = false
    setFinished(null)
    setPaused(false)

    let raf = 0
    let last = performance.now()
    let frame = 0

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop)
      const dt = Math.min(0.05, Math.max(0.0005, (now - last) / 1000))
      last = now
      const g = gameRef.current
      if (!g) return

      const keys = keysRef.current
      const kx = (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0)
      const ky = (keys.has('s') || keys.has('arrowdown') ? 1 : 0) - (keys.has('w') || keys.has('arrowup') ? 1 : 0)
      g.setKbd(kx, ky)

      // 章节说明 / 图鉴打开时冻结世界，只重绘画面
      if (!freezeRef.current) g.update(dt)

      const nowSec = now / 1000
      for (const ev of g.drainEvents()) {
        if (ev.kind === 'imprint') {
          if (nowSec - imprintRef.current > 0.09) {
            imprintRef.current = nowSec
            audio.sfx('imprint')
          }
        } else if (ev.kind === 'fall') audio.sfx('fall')
        else if (ev.kind === 'eaten') audio.sfx('eaten')
        else if (ev.kind === 'touch') audio.sfx('touch')
        else if (ev.kind === 'goal') audio.sfx('goal')
        else if (ev.kind === 'open') audio.sfx('open')
      }
      audio.update(dt, g.light.on, g.light.closed, g.eaterHeat(), g.watcherNear())

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      const introAlpha =
        g.status === 'intro' ? Math.min(1, Math.min(g.introT, 2.9 - g.introT) * 1.6) : 0
      renderer.draw(ctx, g, {
        // 显影阶段整关都显示蓝图，方便玩家先看懂地形
        blueprint: g.status === 'intro' || freezeRef.current ? 1 : blueprintRef.current ? 1 : 0,
        showIntroText: g.status === 'intro' && g.introT < 2.9 && !freezeRef.current,
        introAlpha: Math.max(0, introAlpha),
        hintWhisper: g.hesitation > 9 ? Math.min(1, (g.hesitation - 9) / 2.5) * 0.9 : 0,
      })

      if (++frame % 5 === 0) {
        setHud({
          time: g.time,
          cost: g.cost,
          energy: g.energy,
          hasEnergy: !!lv.energy,
          radius: g.light.radius,
          closed: g.light.closed,
          forcedOff: g.light.forcedOff,
          status: g.status,
          deaths: g.deaths,
          holding: g.status === 'playing' && g.holdTimer > 0,
        })
      }

      if (g.status === 'won' && g.winT > 2.5 && !finishedRef.current) {
        finishedRef.current = true
        const rec: LevelRecord = {
          cost: Math.round(g.cost * 10) / 10,
          time: Math.round(g.time * 10) / 10,
          rating: ratingOf(g.cost, lv.par),
        }
        setFinished({ rating: rec.rating, rec })
        cbRef.current.onComplete(lv.id, rec)
      }
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [levelId])

  /* ── 键盘 ── */
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase()
      // 带 Cmd/Ctrl/Alt 的组合键交给浏览器：这类快捷键常会吞掉 keyup，
      // 一旦漏掉 keyup，方向键就会永久卡住，光点会自己一直往前跑。
      if (e.metaKey || e.ctrlKey || e.altKey) return
      if (k === ' ' || k === 'tab') e.preventDefault()
      // 章节说明 / 图鉴打开时，任意确认键关闭它
      if (freezeRef.current) {
        if (k === ' ' || k === 'escape' || k === 'enter') dismissRef.current()
        return
      }
      if (k === 'tab') blueprintRef.current = true
      if (k === 'escape' || k === 'p') {
        const g = gameRef.current
        if (!g || g.status === 'won' || g.status === 'dying') return
        if (g.status === 'paused') {
          g.resume()
          setPaused(false)
        } else {
          g.pause()
          setPaused(true)
        }
        return
      }
      if (k === 'r') {
        restart()
        return
      }
      if (k === 'q') gameRef.current?.zoom(-16)
      if (k === 'e') gameRef.current?.zoom(16)
      if (k === ' ') {
        audio.ensure()
        gameRef.current?.skipIntro()
        gameRef.current?.setClosed(true)
      }
      keysRef.current.add(k)
    }
    const up = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase()
      if (k === 'tab') blueprintRef.current = false
      if (k === ' ') gameRef.current?.setClosed(false)
      keysRef.current.delete(k)
    }
    /** 任何「键盘状态可能失真」的时刻都清空按键，避免卡键拖着光跑 */
    const release = () => {
      keysRef.current.clear()
      gameRef.current?.setClosed(false)
      blueprintRef.current = false
    }
    const blur = () => {
      release()
      if (gameRef.current?.status === 'playing') {
        gameRef.current.pause()
        setPaused(true)
      }
    }
    const visibility = () => {
      if (document.hidden) {
        release()
        if (gameRef.current?.status === 'playing') {
          gameRef.current.pause()
          setPaused(true)
        }
      }
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    window.addEventListener('blur', blur)
    document.addEventListener('visibilitychange', visibility)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
      window.removeEventListener('blur', blur)
      document.removeEventListener('visibilitychange', visibility)
    }
  }, [restart])

  /* ── 指针：监听整个窗口 ──
     只挂在 canvas 上的话，光标一旦移到 HUD / 页面留白上，瞄准点就冻结，
     而镜头还在平移，看起来就像光点自己往前跑了。 */
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const canvas = canvasRef.current
      if (!canvas) return
      const rect = canvas.getBoundingClientRect()
      if (rect.width < 1 || rect.height < 1) return
      const x = ((e.clientX - rect.left) / rect.width) * VIEW_W
      const y = ((e.clientY - rect.top) / rect.height) * VIEW_H
      pointerRef.current = { x, y }
      if (freezeRef.current) return
      const g = gameRef.current
      if (!g) return
      // 鼠标一动就接管光锥：清掉可能残留的方向键状态，光绝不会自己漂
      keysRef.current.clear()
      if (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom) {
        g.skipIntro()
      }
      g.setPointerScreen(x, y)
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => window.removeEventListener('pointermove', onMove)
  }, [])

  const onPointerDown = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    audio.ensure()
    if (freezeRef.current) return
    const rect = e.currentTarget.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * VIEW_W
    const y = ((e.clientY - rect.top) / rect.height) * VIEW_H
    pointerRef.current = { x, y }
    gameRef.current?.skipIntro()
    gameRef.current?.setPointerScreen(x, y)
  }

  dismissRef.current = () => {
    if (showCodex) setShowCodex(false)
    else if (showBrief) dismissBrief()
  }

  const lv = LEVELS[levelIndexOf(levelId)]
  const hasNext = nextLevelId(levelId) !== null
  const energyPct = Math.round(hud.energy * 100)

  return (
    <div className="relative w-full">
      <div className="relative mx-auto aspect-video w-full max-w-[1500px] overflow-hidden rounded-sm border border-[color:var(--line)] bg-[#070708] shadow-[0_40px_120px_-40px_rgba(0,0,0,0.9)]">
        <canvas
          ref={canvasRef}
          className="h-full w-full cursor-crosshair touch-none select-none"
          onPointerDown={onPointerDown}
          onWheel={(e) => {
            gameRef.current?.zoom(-e.deltaY * 0.22)
          }}
          onContextMenu={(e) => e.preventDefault()}
        />

        {/* HUD */}
        <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-3 sm:p-5">
          <div className="flex items-start justify-between gap-3">
            <div className="lc-panel px-3 py-2 sm:px-4">
              <div className="lc-label">
                第{['一', '二', '三', '四'][lv.chapter - 1]}章 · {lv.chapterName}
              </div>
              <div className="lc-title text-lg sm:text-xl">{lv.name}</div>
            </div>

            <div className="lc-panel hidden max-w-[46%] px-4 py-2 text-center md:block">
              <div
                className={`text-[13px] leading-relaxed ${
                  hud.holding || hud.status === 'intro'
                    ? 'text-[color:var(--warm)]'
                    : 'text-[color:var(--ink-dim)]'
                }`}
              >
                {hud.status === 'intro'
                  ? '显影中……（按空格或点击可跳过）'
                  : hud.holding
                    ? '她站着等你——把光放到前面的路上'
                    : lv.hint}
              </div>
            </div>

            <div className="pointer-events-auto flex items-center gap-1.5">
              <Button
                variant="ghost"
                size="icon"
                className="lc-btn"
                onClick={() => setShowCodex(true)}
                aria-label="机制图鉴"
                title="机制图鉴"
              >
                <BookOpen className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="lc-btn"
                onClick={onToggleMute}
                aria-label="静音"
              >
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="lc-btn"
                onClick={restart}
                aria-label="重来"
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="lc-btn"
                onClick={() => {
                  const g = gameRef.current
                  if (!g) return
                  if (g.status === 'paused') {
                    g.resume()
                    setPaused(false)
                  } else {
                    g.pause()
                    setPaused(true)
                  }
                }}
                aria-label="暂停"
              >
                <Pause className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="mb-2 sm:hidden">
            <div className="lc-panel px-3 py-2 text-center text-[12px] leading-relaxed text-[color:var(--warm)]">
              {hud.status === 'intro'
                ? '显影中……'
                : hud.holding
                  ? '她站着等你——把光放到前面'
                  : lv.hint}
            </div>
          </div>

          <div className="flex items-end justify-between gap-3">
            <div className="lc-panel min-w-[190px] px-3 py-2.5">
              <div className="flex items-center justify-between gap-3">
                <span className="lc-label">
                  {hud.hasEnergy ? '光能' : '无尽之光'}
                </span>
                <span className="lc-num">
                  {hud.hasEnergy ? `${energyPct}%` : '∞'}
                </span>
              </div>
              <div className="mt-1.5 h-[5px] w-full overflow-hidden rounded-full bg-[rgba(220,210,190,0.12)]">
                <div
                  className="h-full rounded-full transition-[width] duration-150"
                  style={{
                    width: `${hud.hasEnergy ? Math.max(4, energyPct) : 100}%`,
                    background:
                      hud.forcedOff || hud.energy < 0.25
                        ? 'linear-gradient(90deg,#8a3b22,#ff6a33)'
                        : 'linear-gradient(90deg,#b8843c,#ffcf8a)',
                  }}
                />
              </div>
              <div className="mt-2 flex items-center justify-between gap-3">
                <span className="lc-label">光耗</span>
                <span className="lc-num">
                  {hud.cost.toFixed(1)} <span className="text-[color:var(--ink-faint)]">/ {lv.par}</span>
                </span>
              </div>
            </div>

            <div className="hidden items-center gap-3 sm:flex">
              <div className="lc-panel px-3 py-2">
                <div className="lc-label">用时</div>
                <div className="lc-num">{hud.time.toFixed(1)}s</div>
              </div>
              <div className="lc-panel px-3 py-2">
                <div className="lc-label">失误</div>
                <div className="lc-num">{hud.deaths}</div>
              </div>
            </div>

            <div className="lc-panel hidden flex-col gap-1.5 px-3 py-2.5 lg:flex">
              <div className="flex items-center gap-2 text-[11px] text-[color:var(--ink-faint)]">
                <Focus className="h-3.5 w-3.5" /> 半径 {Math.round(hud.radius)} · 滚轮/Q·E 调焦
              </div>
              <div className="flex items-center gap-2 text-[11px] text-[color:var(--ink-faint)]">
                <Footprints className="h-3.5 w-3.5" /> WASD·鼠标 移动光锥
              </div>
              <div className="flex items-center gap-2 text-[11px] text-[color:var(--ink-faint)]">
                <EyeOff className="h-3.5 w-3.5" /> 空格 闭眼 · Tab 蓝图
              </div>
            </div>
          </div>
        </div>

        {/* 触屏操作 */}
        {coarse && (
          <div className="pointer-events-none absolute inset-x-0 bottom-24 flex items-center justify-center gap-3">
            <div className="pointer-events-auto flex gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="lc-btn h-12 w-12"
                onPointerDown={() => gameRef.current?.zoom(-18)}
              >
                <ZoomOut className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                className="lc-btn h-12 px-6"
                onPointerDown={() => {
                  audio.ensure()
                  gameRef.current?.setClosed(true)
                }}
                onPointerUp={() => gameRef.current?.setClosed(false)}
                onPointerLeave={() => gameRef.current?.setClosed(false)}
              >
                <EyeOff className="mr-2 h-4 w-4" /> 闭眼
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="lc-btn h-12 w-12"
                onPointerDown={() => gameRef.current?.zoom(18)}
              >
                <ZoomIn className="h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {/* 闭眼提示 */}
        {hud.closed && hud.status === 'playing' && (
          <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="lc-label animate-pulse-soft text-center text-[13px]">
              {hud.hasEnergy ? '闭眼 · 光能在黑暗中恢复' : '闭眼 · 世界沉入黑水'}
            </div>
          </div>
        )}

        {/* 暂停 */}
        {paused && (
          <div className="absolute inset-0 flex items-center justify-center bg-[rgba(6,6,8,0.78)] backdrop-blur-sm">
            <div className="lc-panel w-[min(92%,430px)] p-6 text-center">
              <div className="lc-title text-3xl">暂停</div>
              <div className="mt-1 text-[13px] text-[color:var(--ink-dim)]">
                光还悬在那里，世界也停在原地。
              </div>
              <div className="mt-6 flex flex-col gap-2">
                <Button
                  className="lc-primary"
                  onClick={() => {
                    gameRef.current?.resume()
                    setPaused(false)
                  }}
                >
                  <Play className="mr-2 h-4 w-4" /> 继续注视
                </Button>
                <Button variant="ghost" className="lc-ghost" onClick={restart}>
                  <RotateCcw className="mr-2 h-4 w-4" /> 重来本关
                </Button>
                <Button
                  variant="ghost"
                  className="lc-ghost"
                  onClick={() => {
                    setPaused(false)
                    setShowCodex(true)
                  }}
                >
                  <BookOpen className="mr-2 h-4 w-4" /> 机制图鉴
                </Button>
                <Button variant="ghost" className="lc-ghost" onClick={onExit}>
                  <X className="mr-2 h-4 w-4" /> 返回目录
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* 章节开场：这一关第一次出现的东西 */}
        {showBrief && brief.length > 0 && (
          <CodexOverlay
            title={lv.name}
            subtitle={`第${['一', '二', '三', '四'][lv.chapter - 1]}章 · ${lv.chapterName} —— 第一次出现的东西`}
            entries={brief}
            primaryLabel="知道了，开始"
            onPrimary={dismissBrief}
            columns={1}
          />
        )}

        {/* 机制图鉴 */}
        {showCodex && (
          <CodexOverlay
            title="机制图鉴"
            subtitle={`你已经见过 ${seenCodex.length} 条规则`}
            entries={seenCodex}
            primaryLabel="回到注视"
            onPrimary={() => setShowCodex(false)}
            secondaryLabel="继续"
            onSecondary={() => setShowCodex(false)}
            columns={2}
          />
        )}

        {/* 结算 */}
        {finished && (
          <div className="absolute inset-0 flex items-center justify-center bg-[rgba(6,6,8,0.82)] backdrop-blur-sm">
            <div className="lc-panel w-[min(92%,520px)] p-7 text-center">
              <div className="lc-label">显影完成</div>
              <div className="lc-title mt-1 text-3xl">{lv.name}</div>
              <div
                className="mt-4 text-4xl tracking-[0.3em]"
                style={{ color: RATING[finished.rating].color }}
              >
                {RATING[finished.rating].name}
              </div>
              <div className="mt-2 text-[13px] text-[color:var(--ink-dim)]">
                {RATING[finished.rating].desc}
              </div>

              <div className="mt-6 grid grid-cols-3 gap-2 text-left">
                <div className="lc-stat">
                  <div className="lc-label">光耗</div>
                  <div className="lc-num-lg">{finished.rec.cost.toFixed(1)}</div>
                  <div className="lc-label">目标 {lv.par}</div>
                </div>
                <div className="lc-stat">
                  <div className="lc-label">用时</div>
                  <div className="lc-num-lg">{finished.rec.time.toFixed(1)}</div>
                  <div className="lc-label">秒</div>
                </div>
                <div className="lc-stat">
                  <div className="lc-label">失误</div>
                  <div className="lc-num-lg">{hud.deaths}</div>
                  <div className="lc-label">次</div>
                </div>
              </div>

              <div className="mt-4 text-[13px] italic leading-relaxed text-[color:var(--warm)]/85">
                「{lv.outro}」
              </div>

              <div className="mt-6 flex flex-wrap justify-center gap-2">
                <Button variant="ghost" className="lc-ghost" onClick={restart}>
                  <RotateCcw className="mr-2 h-4 w-4" /> 再走一次
                </Button>
                {hasNext && (
                  <Button
                    className="lc-primary"
                    onClick={() => onGoLevel(nextLevelId(levelId) as string)}
                  >
                    下一关 <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                )}
                <Button variant="ghost" className="lc-ghost" onClick={onExit}>
                  <ArrowLeft className="mr-2 h-4 w-4" /> 关卡目录
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="mx-auto mt-3 flex max-w-[1500px] flex-wrap items-center justify-between gap-2 px-1">
        <Button variant="ghost" className="lc-ghost" onClick={onExit}>
          <ArrowLeft className="mr-2 h-4 w-4" /> 关卡目录
        </Button>
        <div className="text-[12px] text-[color:var(--ink-faint)]">
          它只会向前走。你唯一能做的是——看，或者不看。
        </div>
      </div>
    </div>
  )
}
