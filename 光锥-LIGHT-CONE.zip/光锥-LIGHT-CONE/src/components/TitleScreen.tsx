import HeroCanvas from './HeroCanvas'
import { Button } from '@/components/ui/button'
import { LEVELS } from '@/game/levels'
import { BookOpen, Eye, LayoutGrid, MousePointer2, Volume2, VolumeX } from 'lucide-react'

type Props = {
  onStart: () => void
  onSelect: () => void
  onHow: () => void
  resumeLabel: string
  muted: boolean
  onToggleMute: () => void
  cleared: number
}

export default function TitleScreen({
  onStart,
  onSelect,
  onHow,
  resumeLabel,
  muted,
  onToggleMute,
  cleared,
}: Props) {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* 背景氛围 */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-[-18%] h-[560px] w-[860px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,196,110,0.09),transparent_66%)] blur-2xl" />
        <div className="lc-scan absolute inset-0 opacity-60" />
      </div>

      <div className="relative mx-auto flex min-h-screen w-full max-w-[1180px] flex-col px-5 pb-10 pt-6 sm:px-8">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Eye className="h-4 w-4 text-[color:var(--warm)]" />
            <span className="lc-label">观察者效应 · 解谜</span>
          </div>
          <Button variant="ghost" size="icon" className="lc-btn" onClick={onToggleMute} aria-label="静音">
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
        </header>

        <main className="flex flex-1 flex-col items-center justify-center py-8">
          <div className="text-center">
            <h1 className="lc-title text-[64px] leading-none sm:text-[92px]">光锥</h1>
            <div className="mt-3 flex items-center justify-center gap-4">
              <span className="lc-hr w-10 sm:w-16" />
              <span className="text-[13px] tracking-[0.62em] text-[color:var(--ink-dim)]">
                LIGHT CONE
              </span>
              <span className="lc-hr w-10 sm:w-16" />
            </div>
            <p className="mt-4 text-[15px] tracking-[0.3em] text-[color:var(--warm)]/90">
              我见，故你在
            </p>
          </div>

          <div className="mt-8 w-full overflow-hidden rounded-[3px] border border-[color:var(--line)] bg-[#08080a]">
            <HeroCanvas />
          </div>

          <p className="mt-6 max-w-[720px] text-center text-[14px] leading-[2] text-[color:var(--ink-dim)]">
            你不能移动她，不能攻击，也不能跳跃。
            <br />
            <span className="text-[color:var(--ink)]">你唯一能做的，是决定光落在哪里。</span>
            被照亮的地方才会实体化——而黑暗中，连怪物都不存在。
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Button className="lc-primary px-8" onClick={onStart}>
              {resumeLabel}
            </Button>
            <Button variant="ghost" className="lc-ghost px-6" onClick={onSelect}>
              <LayoutGrid className="mr-2 h-4 w-4" /> 关卡目录
            </Button>
            <Button variant="ghost" className="lc-ghost px-6" onClick={onHow}>
              <BookOpen className="mr-2 h-4 w-4" /> 玩法说明
            </Button>
          </div>

          <div className="mt-7 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[12px] text-[color:var(--ink-faint)]">
            <span className="flex items-center gap-2">
              <MousePointer2 className="h-3.5 w-3.5" /> 鼠标 / WASD 移动光锥
            </span>
            <span className="flex items-center gap-2">
              <Eye className="h-3.5 w-3.5" /> 按住空格闭眼 · 闭眼时恢复光能
            </span>
            <span>滚轮 调焦 · Tab 蓝图</span>
          </div>

          <div className="mt-10 w-full">
            <div className="mb-3 flex items-center justify-between">
              <span className="lc-label">四章 · 十关 · 已显影 {cleared}/{LEVELS.length}</span>
            </div>
            <div className="grid gap-2 sm:grid-cols-4">
              {[1, 2, 3, 4].map((c) => {
                const lv = LEVELS.find((l) => l.chapter === c)
                const done = LEVELS.filter((l) => l.chapter === c).length
                return (
                  <div key={c} className="lc-card">
                    <div className="lc-label">第{['一', '二', '三', '四'][c - 1]}章</div>
                    <div className="mt-1 text-[15px] tracking-[0.16em] text-[color:var(--ink)]">
                      {lv?.chapterName}
                    </div>
                    <div className="mt-1 text-[11px] text-[color:var(--ink-faint)]">{done} 关</div>
                  </div>
                )
              })}
            </div>
          </div>
        </main>

        <footer className="mt-6 text-center text-[11px] tracking-[0.28em] text-[color:var(--ink-faint)]">
          大多数游戏让你变强。这一款，只让你学会分配注意力。
        </footer>
      </div>
    </div>
  )
}
