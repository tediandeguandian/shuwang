import { useCallback, useEffect, useMemo, useState } from 'react'
import TitleScreen from '@/components/TitleScreen'
import HowToPlay from '@/components/HowToPlay'
import LevelSelect from '@/components/LevelSelect'
import GameStage from '@/components/GameStage'
import { LEVELS } from '@/game/levels'
import { audio } from '@/game/audio'
import { knownLevelIds } from '@/game/codex'
import { loadSave, persistSave, RATING_ORDER } from '@/game/storage'
import type { SaveData } from '@/game/storage'
import type { LevelRecord } from '@/game/types'
import './App.css'

type Screen = 'title' | 'how' | 'select' | 'game'

export default function App() {
  const [save, setSave] = useState<SaveData>(() => loadSave())
  const [screen, setScreen] = useState<Screen>('title')
  const [levelId, setLevelId] = useState<string>(LEVELS[0].id)

  useEffect(() => {
    persistSave(save)
  }, [save])

  useEffect(() => {
    audio.setMuted(save.muted)
  }, [save.muted])

  const cleared = LEVELS.filter((l) => save.progress[l.id]).length

  /** 已经知道内容的关卡：图鉴、关卡目录、玩法说明都以它为准，避免提前剧透 */
  const knownIds = useMemo(
    () => knownLevelIds(save.progress, save.seenBriefs),
    [save.progress, save.seenBriefs],
  )

  const resume = useMemo(() => {
    const idx = LEVELS.findIndex((l) => !save.progress[l.id])
    if (idx < 0) return { id: LEVELS[LEVELS.length - 1].id, label: '重温最后一章' }
    const lv = LEVELS[idx]
    return { id: lv.id, label: idx === 0 ? '开始注视' : `继续 · ${lv.name}` }
  }, [save.progress])

  const toggleMute = useCallback(() => {
    setSave((s) => ({ ...s, muted: !s.muted }))
  }, [])

  const handleComplete = useCallback((id: string, rec: LevelRecord) => {
    setSave((s) => {
      const prev = s.progress[id]
      const better =
        !prev ||
        RATING_ORDER.indexOf(rec.rating) > RATING_ORDER.indexOf(prev.rating) ||
        (RATING_ORDER.indexOf(rec.rating) === RATING_ORDER.indexOf(prev.rating) &&
          rec.cost < prev.cost)
      const progress = better ? { ...s.progress, [id]: rec } : s.progress
      const allDone = LEVELS.every((l) => progress[l.id])
      return { ...s, progress, cleared: s.cleared || allDone }
    })
  }, [])

  const startLevel = useCallback((id: string) => {
    setLevelId(id)
    setScreen('game')
  }, [])

  const markBriefSeen = useCallback((id: string) => {
    setSave((s) => (s.seenBriefs.includes(id) ? s : { ...s, seenBriefs: [...s.seenBriefs, id] }))
  }, [])

  return (
    <div className="min-h-screen w-full bg-[#08080a] text-[color:var(--ink)]">
      {screen === 'title' && (
        <TitleScreen
          onStart={() => startLevel(resume.id)}
          onSelect={() => setScreen('select')}
          onHow={() => setScreen('how')}
          resumeLabel={resume.label}
          muted={save.muted}
          onToggleMute={toggleMute}
          cleared={cleared}
        />
      )}

      {screen === 'how' && (
        <HowToPlay
          knownIds={knownIds}
          onBack={() => setScreen('title')}
          onStart={() => startLevel(resume.id)}
        />
      )}

      {screen === 'select' && (
        <LevelSelect
          progress={save.progress}
          knownIds={knownIds}
          onPick={startLevel}
          onBack={() => setScreen('title')}
        />
      )}

      {screen === 'game' && (
        <div className="flex min-h-screen w-full items-center justify-center px-3 py-4 sm:px-6">
          <GameStage
            levelId={levelId}
            muted={save.muted}
            knownIds={knownIds}
            onToggleMute={toggleMute}
            onExit={() => setScreen('select')}
            onComplete={handleComplete}
            onGoLevel={startLevel}
            onBriefSeen={markBriefSeen}
          />
        </div>
      )}
    </div>
  )
}
