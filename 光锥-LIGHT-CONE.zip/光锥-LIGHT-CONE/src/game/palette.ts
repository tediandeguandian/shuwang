/** 炭笔世界调色板：近乎单色，唯一的高饱和色属于玩家光锥里的钨丝暖黄 */
export const PALETTE = {
  bg: '#0a0a0b',
  bgDeep: '#070708',
  stoneFill: '#131317',
  stoneEdge: '#3a3a43',
  stoneHatch: '#22222a',
  paperLit: '#ece3cf',
  paperLitHatch: '#3b3529',
  paperLitEdge: '#1d1a15',
  after: '#c9a468',
  afterHatch: '#4d4028',
  afterEdge: '#7a5f34',
  blueprint: 'rgba(206,196,172,0.5)',
  ink: '#07070a',
  eye: '#ff6a33',
  cold: '#93a7bd',
  coldDeep: '#3d4a5a',
  warm: '#ffcf8a',
  warmDeep: '#b8843c',
  char: '#f2ead8',
  charEdge: '#16140f',
} as const

export type Palette = typeof PALETTE
