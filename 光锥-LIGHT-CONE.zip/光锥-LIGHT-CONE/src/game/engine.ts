import type {
  CharState,
  DeathCause,
  EaterState,
  GameEvent,
  GameStatus,
  Level,
  LightState,
  PaperState,
  Particle,
  Rect,
  WatcherState,
} from './types'
import { LANE_Y } from './levels'
import { clamp, easeInOut, hash01, lerp } from './sketch'

export const VIEW_W = 1280
export const VIEW_H = 720
export const BASE_R = 185
export const MIN_R = 88
export const MAX_R = 330
export const AFTERIMAGE = 1.35
export const CHAR_W = 26
export const CHAR_H = 46
export const EATER_W = 46
export const EATER_H = 52
export const WATCHER_W = 30
export const WATCHER_H = 54

const WALK = 108
const GRAVITY = 1500
const MAX_FALL = 1400
const KBD_SPEED = 560

const overlap = (a: Rect, b: Rect): boolean =>
  a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y

const closestDist = (r: Rect, px: number, py: number): number => {
  const cx = clamp(px, r.x, r.x + r.w)
  const cy = clamp(py, r.y, r.y + r.h)
  return Math.hypot(cx - px, cy - py)
}

export class Game {
  level: Level
  status: GameStatus = 'intro'
  introT = 0
  t = 0
  time = 0
  cost = 0
  deaths = 0
  breathCount = 0

  paper: PaperState[]
  eaters: EaterState[]
  watchers: WatcherState[]
  char: CharState
  light: LightState
  energy = 1
  camX = 0
  particles: Particle[] = []
  events: GameEvent[] = []
  shake = 0
  flash = 0
  doorSeal = 1
  hesitation = 0

  /** 玩家输入：瞄准点存储为「屏幕坐标」，这样镜头平移时光点会一直跟着鼠标 */
  private closedInput = false
  private aimScreen = { x: 0, y: 0 }
  private kbd = { x: 0, y: 0 }

  /** 开场停顿：她站着等你把光放好 */
  holdTimer = 0
  respawn = { x: 0, y: 0 }
  checkpoints: { x: number; y: number }[] = []
  deathCause: DeathCause | null = null
  deathTimer = 0
  winT = 0
  solids: Rect[] = []

  constructor(level: Level) {
    this.level = level
    this.paper = []
    this.eaters = []
    this.watchers = []
    this.char = {
      x: level.spawn.x,
      y: level.spawn.y,
      w: CHAR_W,
      h: CHAR_H,
      vy: 0,
      grounded: false,
      blocked: false,
      walk: 0,
    }
    this.light = {
      x: level.spawn.x + 200,
      y: LANE_Y - 90,
      radius: BASE_R,
      targetRadius: BASE_R,
      closed: false,
      forcedOff: false,
      on: true,
    }
    this.build()
  }

  private build(): void {
    const lv = this.level
    this.paper = lv.paper.map((r, i) => ({ ...r, lit: false, lastLit: -99, seed: 3.7 + i * 5.13 }))
    this.eaters = lv.eaters.map((e, i) => ({
      x: e.x,
      y: LANE_Y - EATER_H,
      w: EATER_W,
      h: EATER_H,
      lit: false,
      wake: 0,
      seed: 11.3 + i * 4.7,
    }))
    this.watchers = lv.watchers.map((w, i) => ({
      x: w.x,
      y: LANE_Y - WATCHER_H,
      w: WATCHER_W,
      h: WATCHER_H,
      dir: -1,
      speed: w.speed ?? 58,
      frozen: false,
      seed: 23.1 + i * 6.3,
    }))
    // 自动生成存档点：每块石地（同一水平线）的起点
    const cps = [{ x: lv.spawn.x, y: lv.spawn.y }]
    lv.stone
      .filter((r) => Math.abs(r.y - LANE_Y) < 1)
      .sort((a, b) => a.x - b.x)
      .forEach((r) => {
        const x = r.x + 24
        if (x > lv.spawn.x + 120 && !cps.some((c) => Math.abs(c.x - x) < 80)) {
          cps.push({ x, y: LANE_Y - CHAR_H })
        }
      })
    this.checkpoints = cps
    this.respawn = { ...cps[0] }
    this.char.x = lv.spawn.x
    this.char.y = lv.spawn.y
    this.energy = lv.energy ? lv.energy.start : 1
    this.camX = clamp(lv.spawn.x - VIEW_W * 0.42, 0, this.maxCamX())
    this.light.closed = false
    this.light.forcedOff = false
    this.aimScreen = { x: this.light.x - this.camX, y: this.light.y }
  }

  private maxCamX(): number {
    return Math.max(0, this.level.width - VIEW_W)
  }

  /* ─────────────── 输入 ─────────────── */

  /** 指针位置（画布坐标，0..VIEW_W / 0..VIEW_H） */
  setPointerScreen(sx: number, sy: number): void {
    this.aimScreen.x = clamp(sx, -20, VIEW_W + 20)
    this.aimScreen.y = clamp(sy, 10, VIEW_H - 10)
  }

  /** 开场停顿：让玩家有时间把光放好 */
  hold(seconds: number): void {
    this.holdTimer = Math.max(this.holdTimer, seconds)
  }

  setKbd(x: number, y: number): void {
    this.kbd.x = x
    this.kbd.y = y
  }

  setClosed(b: boolean): void {
    if (b && !this.closedInput && this.status === 'playing') this.breathCount++
    this.closedInput = b
  }

  zoom(delta: number): void {
    this.light.targetRadius = clamp(this.light.targetRadius + delta, MIN_R, MAX_R)
  }

  resume(): void {
    if (this.status === 'paused') this.status = 'playing'
  }

  pause(): void {
    if (this.status === 'playing') this.status = 'paused'
  }

  skipIntro(): void {
    if (this.status === 'intro') {
      this.introT = 99
      this.status = 'playing'
      this.holdTimer = Math.min(this.holdTimer, 1)
    }
  }

  private kill(cause: DeathCause): void {
    if (this.status !== 'playing') return
    this.deathCause = cause
    this.status = 'dying'
    this.deathTimer = 1.05
    this.deaths++
    this.shake = cause === 'abyss' ? 0.5 : 0.85
    this.events.push({ kind: cause === 'abyss' ? 'fall' : cause === 'eaten' ? 'eaten' : 'touch' })
    for (let i = 0; i < 26; i++) {
      this.particles.push({
        x: this.char.x + CHAR_W / 2,
        y: this.char.y + CHAR_H / 2,
        vx: (Math.random() - 0.5) * 320,
        vy: -80 - Math.random() * 220,
        life: 0.9,
        max: 0.9,
        size: 1 + Math.random() * 3,
        tone: i % 3 === 0 ? 1 : 0,
      })
    }
  }

  private respawnNow(): void {
    const c = this.char
    c.x = this.respawn.x
    c.y = this.respawn.y
    c.vy = 0
    c.grounded = false
    c.blocked = false
    this.status = 'playing'
    this.deathCause = null
    this.flash = 0.35
    this.eaters.forEach((e, i) => {
      e.x = this.level.eaters[i].x
      e.wake = 0
      e.lit = false
    })
    this.watchers.forEach((w, i) => {
      w.x = this.level.watchers[i].x
      w.frozen = false
      w.dir = -1
    })
    // 光锥不重置：它始终是玩家鼠标的位置，重生后也绝不脱离指针
  }

  /* ─────────────── 主循环 ─────────────── */

  update(rawDt: number): void {
    const dt = Math.min(rawDt, 1 / 30)
    this.t += dt
    this.shake = Math.max(0, this.shake - dt * 2.2)
    this.flash = Math.max(0, this.flash - dt * 1.6)
    this.updateParticles(dt)

    if (this.status === 'intro') {
      this.introT += dt
      this.updateCamera(dt)
      this.trackLight()
      if (this.introT > 2.9) {
        this.status = 'playing'
        this.holdTimer = this.level.hold ?? 2.2
      }
      return
    }

    if (this.status === 'dying') {
      this.deathTimer -= dt
      this.updateCamera(dt)
      // 死亡动画期间光也照样跟着鼠标，绝不脱手
      this.trackLight()
      if (this.deathTimer <= 0) this.respawnNow()
      return
    }

    if (this.status === 'won') {
      this.winT += dt
      this.updateCamera(dt)
      this.trackLight()
      return
    }

    if (this.status === 'paused') {
      this.trackLight()
      return
    }

    this.time += dt
    this.updateLight(dt)
    this.updatePaper()
    this.updateEaters(dt)
    this.updateWatchers(dt)
    this.updateChar(dt)
    this.checkHazards()
    this.updateGoal(dt)
    this.updateCamera(dt)
    // 镜头刚移动过，再贴合一次，保证光点与指针零误差
    this.trackLight()
  }

  /**
   * 把光锥放到指针的屏幕位置上。
   * 位置直接吸附、不做插值，且在任何状态下都会执行：
   * 镜头平移、鼠标甩动、死亡动画、暂停——光都不会离开指针。
   */
  private trackLight(): void {
    this.light.x = this.aimScreen.x + this.camX
    this.light.y = clamp(this.aimScreen.y, 40, this.level.height - 30)
  }

  private updateLight(dt: number): void {
    const lv = this.level
    const L = this.light

    // 键盘移动光锥（同样作用在屏幕坐标上）
    if (this.kbd.x !== 0 || this.kbd.y !== 0) {
      this.aimScreen.x = clamp(this.aimScreen.x + this.kbd.x * KBD_SPEED * dt, -20, VIEW_W + 20)
      this.aimScreen.y = clamp(this.aimScreen.y + this.kbd.y * KBD_SPEED * dt, 10, VIEW_H - 10)
    }

    this.trackLight()
    // 只有焦距保留一点惯性，让缩放有重量感
    L.radius = lerp(L.radius, L.targetRadius, Math.min(1, dt * 10))

    L.closed = this.closedInput
    L.on = !this.closedInput && !L.forcedOff

    const powFactor = Math.pow(L.radius / BASE_R, 2)
    const hasEnergy = !!lv.energy
    if (L.on) {
      this.cost += powFactor * dt
      if (hasEnergy && lv.energy) {
        this.energy -= lv.energy.drain * powFactor * dt
        if (this.energy <= 0) {
          this.energy = 0
          L.forcedOff = true
          L.on = false
        }
      }
    } else if (hasEnergy && lv.energy) {
      this.energy = Math.min(1, this.energy + lv.energy.refill * dt)
      if (L.forcedOff && this.energy >= 0.3) L.forcedOff = false
    }
    if (!hasEnergy) this.energy = 1
  }

  private isLit(r: Rect): boolean {
    const L = this.light
    if (!L.on) return false
    return closestDist(r, L.x, L.y) <= L.radius
  }

  private updatePaper(): void {
    for (const p of this.paper) {
      const lit = this.isLit(p)
      if (lit && !p.lit) this.events.push({ kind: 'imprint' })
      p.lit = lit
      if (lit) p.lastLit = this.t
    }
  }

  private updateEaters(dt: number): void {
    for (const e of this.eaters) {
      const lit = this.isLit(e)
      if (lit && !e.lit) this.events.push({ kind: 'wake' })
      e.lit = lit
      const target = lit ? 1 : 0
      e.wake += (target - e.wake) * Math.min(1, dt * (lit ? 9 : 2.5))
    }
  }

  private updateWatchers(dt: number): void {
    for (const w of this.watchers) {
      w.frozen = this.isLit(w)
      if (!w.frozen) {
        const target = this.char.x + CHAR_W / 2
        const cx = w.x + w.w / 2
        const dir = Math.sign(target - cx) || -1
        w.dir = dir
        const step = w.speed * dt
        if (dir > 0) w.x = Math.min(w.x + step, target - 4)
        else w.x = Math.max(w.x - step, target + 4)
      }
    }
  }

  private updateChar(dt: number): void {
    const c = this.char
    this.getSolids()
    // 开场停顿：她还站着，等你把光放好
    const advancing = this.holdTimer <= 0
    if (!advancing) this.holdTimer -= dt
    c.blocked = !advancing
    // 水平：永远向前走
    if (advancing) c.x += WALK * dt
    for (const s of this.solids) {
      if (!overlap(c, s)) continue
      c.x = s.x - c.w
      c.blocked = true
    }
    // 垂直
    c.vy = Math.min(c.vy + GRAVITY * dt, MAX_FALL)
    const prevBottom = c.y + c.h
    c.y += c.vy * dt
    let grounded = false
    for (const s of this.solids) {
      if (!overlap(c, s)) continue
      if (c.vy >= 0 && prevBottom <= s.y + 10) {
        c.y = s.y - c.h
        c.vy = 0
        grounded = true
      } else if (c.vy < 0) {
        c.y = s.y + s.h
        c.vy = 0
      } else {
        c.y = s.y - c.h
        c.vy = 0
        grounded = true
      }
    }
    // 站立探针：脚下一小段范围内有实体即算站稳
    if (!grounded) {
      const probe: Rect = { x: c.x + 3, y: c.y + c.h - 1, w: c.w - 6, h: 5 }
      for (const s of this.solids) {
        if (!overlap(probe, s)) continue
        c.y = s.y - c.h
        c.vy = 0
        grounded = true
        break
      }
    }
    c.grounded = grounded
    if (c.grounded) c.walk += dt * 9

    // 存档点
    if (c.grounded) {
      for (const cp of this.checkpoints) {
        if (cp.x <= c.x && cp.x > this.respawn.x) this.respawn = { ...cp }
      }
    }
  }

  private checkHazards(): void {
    const c = this.char
    if (c.y > this.level.height + 30) {
      this.kill('abyss')
      return
    }
    for (const e of this.eaters) {
      if (e.lit && overlap(e, c)) {
        this.kill('eaten')
        return
      }
    }
    for (const w of this.watchers) {
      // 被注视时，逆视者被压成一张纸，可以穿过去
      if (w.frozen) continue
      if (overlap(w, c)) {
        this.kill('watcher')
        return
      }
    }
  }

  private updateGoal(dt: number): void {
    const g = this.level.goal
    const open = g.requiresDark ? !this.light.on : true
    this.doorSeal = lerp(this.doorSeal, open ? 0 : 1, Math.min(1, dt * 5))
    if (open && overlap(g, this.char)) {
      this.status = 'won'
      this.winT = 0
      this.flash = 1
      this.events.push({ kind: 'goal' })
      for (let i = 0; i < 60; i++) {
        this.particles.push({
          x: g.x + g.w / 2,
          y: g.y + g.h / 2,
          vx: (Math.random() - 0.5) * 420,
          vy: (Math.random() - 0.5) * 420,
          life: 1.6,
          max: 1.6,
          size: 1 + Math.random() * 3,
          tone: 1,
        })
      }
      return
    }
    // 卡在熄灯门前太久，给一句提示
    if (g.requiresDark && !open && Math.abs(this.char.x + this.char.w / 2 - (g.x + g.w / 2)) < g.w) {
      this.hesitation += dt
    } else if (!g.requiresDark) {
      this.hesitation = 0
    }
  }

  private updateCamera(dt: number): void {
    const maxX = this.maxCamX()
    if (this.status === 'intro') {
      const p = easeInOut(Math.min(1, this.introT / 2.6))
      const fromX = clamp(this.level.spawn.x - VIEW_W * 0.42, 0, maxX)
      const toX = clamp(this.level.goal.x - VIEW_W * 0.55, 0, maxX)
      this.camX = lerp(fromX, toX, p)
      return
    }
    const focus = this.char.x * 0.72 + this.light.x * 0.28
    const target = clamp(focus - VIEW_W * 0.42, 0, maxX)
    this.camX = lerp(this.camX, target, Math.min(1, dt * 3.4))
  }

  private updateParticles(dt: number): void {
    const ps = this.particles
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i]
      p.life -= dt
      if (p.life <= 0) {
        ps.splice(i, 1)
        continue
      }
      p.vy += 140 * dt
      p.x += p.vx * dt
      p.y += p.vy * dt
      p.vx *= 1 - dt * 0.9
    }
    if (ps.length > 420) ps.splice(0, ps.length - 420)
  }

  private getSolids(): Rect[] {
    const out: Rect[] = []
    for (const s of this.level.stone) out.push(s)
    for (const p of this.paper) {
      if (p.lit || this.t - p.lastLit < AFTERIMAGE) out.push(p)
    }
    this.solids = out
    return out
  }

  /** 取走并清空本帧事件（音效用） */
  drainEvents(): GameEvent[] {
    if (this.events.length === 0) return this.events
    const e = this.events
    this.events = []
    return e
  }

  /* ─────────────── 查询 ─────────────── */

  eaterHeat(): number {
    let h = 0
    for (const e of this.eaters) h = Math.max(h, e.wake)
    return h
  }

  watcherNear(): number {
    let n = 0
    for (const w of this.watchers) {
      const d = Math.abs(w.x - this.char.x)
      n = Math.max(n, clamp(1 - d / 900, 0, 1))
    }
    return n
  }

  dust(i: number): { x: number; y: number; r: number } {
    const L = this.light
    const a = hash01(i * 3.77 + 1.3) * Math.PI * 2
    const rr = Math.sqrt(hash01(i * 7.13 + 4.9)) * this.light.radius * 0.96
    const drift = (this.t * (0.12 + hash01(i * 2.1) * 0.3)) % 1
    const ang = a + drift * 0.7
    return {
      x: L.x + Math.cos(ang) * rr,
      y: L.y + Math.sin(ang) * rr * 0.8 - drift * 26,
      r: 0.6 + hash01(i * 5.5) * 1.7,
    }
  }
}
