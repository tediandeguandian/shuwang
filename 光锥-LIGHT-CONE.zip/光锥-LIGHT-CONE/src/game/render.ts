import type { Game } from './engine'
import { AFTERIMAGE, CHAR_H, VIEW_H, VIEW_W } from './engine'
import {
  boil,
  clamp,
  hash01,
  hatch,
  makeFiberTile,
  makeNoiseTile,
  rectPts,
  sketchPath,
} from './sketch'
import type { Pt } from './sketch'
import { PALETTE } from './palette'

const C = PALETTE

export type RenderOptions = {
  blueprint: number
  showIntroText: boolean
  introAlpha: number
  hintWhisper: number
}

type Shape = { pts: Pt[]; alpha: number }

const buildBackdrop = (seed: number, width: number, laneY: number): Shape[] => {
  const shapes: Shape[] = []
  let x = -200
  let i = 0
  while (x < width + 400) {
    const w = 90 + hash01(seed + i * 1.71) * 240
    const h = 50 + hash01(seed + i * 2.37) * 175
    const top = laneY - h
    const t = 22 + hash01(seed + i * 3.13) * 34
    shapes.push({
      pts: [
        { x, y: laneY },
        { x: x + t * 0.2, y: top + 14 },
        { x: x + t * 0.55, y: top },
        { x: x + w - t * 0.5, y: top + hash01(seed + i * 5.1) * 26 },
        { x: x + w, y: laneY },
      ],
      alpha: 0.55 + hash01(seed + i * 7.7) * 0.45,
    })
    x += w + 70 + hash01(seed + i * 4.29) * 190
    i++
  }
  return shapes
}

export class Renderer {
  private noise: HTMLCanvasElement
  private fiber: HTMLCanvasElement
  private backdropKey = ''
  private backdrop: Shape[] = []

  constructor() {
    this.noise = makeNoiseTile(160, 30)
    this.fiber = makeFiberTile(220)
  }

  draw(ctx: CanvasRenderingContext2D, g: Game, o: RenderOptions): void {
    const t = g.t
    const step = boil(t)
    const camX = g.camX
    const shakeX = g.shake > 0 ? (hash01(Math.floor(t * 60) * 1.7) - 0.5) * 26 * g.shake : 0
    const shakeY = g.shake > 0 ? (hash01(Math.floor(t * 60) * 3.1 + 9) - 0.5) * 22 * g.shake : 0

    ctx.save()
    ctx.fillStyle = C.bgDeep
    ctx.fillRect(0, 0, VIEW_W, VIEW_H)

    this.drawBackdrop(ctx, g, camX, step)

    ctx.save()
    ctx.translate(-camX + shakeX, shakeY)

    this.drawBlueprint(ctx, g, o, step)
    this.drawStone(ctx, g, camX, step)
    this.drawPaper(ctx, g, camX, t, step)
    this.drawEaters(ctx, g, camX, t, step)
    this.drawCheckpoints(ctx, g, camX, step)
    this.drawGoal(ctx, g, t, step)
    this.drawWatchers(ctx, g, camX, t, step)

    if (g.status !== 'dying') this.drawChar(ctx, g, t, step)
    this.drawParticles(ctx, g)

    // 光锥与黑暗层必须画在世界坐标系里。
    // L.x / L.y 是世界坐标；若放到 ctx.restore() 之后（屏幕空间）绘制，
    // 就会再叠加一次镜头偏移 —— 表现为镜头每平移 1px，光点就比鼠标多跑 1px。
    this.drawCone(ctx, g, t)
    this.drawDarkness(ctx, g, camX)

    ctx.restore()

    this.drawGrain(ctx, g, o)
    this.drawVignette(ctx)
    this.drawOverlays(ctx, g, o)
    ctx.restore()
  }

  /* ── 背景 ── */
  private drawBackdrop(ctx: CanvasRenderingContext2D, g: Game, camX: number, step: number): void {
    const key = g.level.id
    if (this.backdropKey !== key) {
      this.backdrop = buildBackdrop(key.length * 7.3 + g.level.width * 0.01, g.level.width, 560)
      this.backdropKey = key
    }
    ctx.save()
    ctx.translate(-camX * 0.42, 0)
    ctx.lineWidth = 1.5
    for (const s of this.backdrop) {
      const last = s.pts[s.pts.length - 1]
      if (last.x < camX * 0.42 - 300 || s.pts[0].x > camX * 0.42 + VIEW_W + 300) continue
      ctx.fillStyle = `rgba(255,252,244,${0.018 * s.alpha})`
      sketchPath(ctx, s.pts, hash01(s.pts[0].x) * 100, step, 2.2, true)
      ctx.fill()
      ctx.strokeStyle = `rgba(226,220,208,${0.05 * s.alpha})`
      ctx.stroke()
    }
    ctx.restore()

    // 纸纤维
    const pat = ctx.createPattern(this.fiber, 'repeat')
    if (pat) {
      ctx.save()
      ctx.translate(-camX * 0.18, 0)
      ctx.fillStyle = pat
      ctx.fillRect(camX * 0.18 - 100, 0, VIEW_W + 400, VIEW_H)
      ctx.restore()
    }
  }

  /* ── 蓝图：未点亮的世界草图 ── */
  private drawBlueprint(
    ctx: CanvasRenderingContext2D,
    g: Game,
    o: RenderOptions,
    step: number,
  ): void {
    const a = 0.07 + o.blueprint * 0.34
    if (a <= 0.01) return
    ctx.save()
    ctx.setLineDash([7, 9])
    ctx.lineWidth = 1.2
    ctx.strokeStyle = `rgba(206,196,172,${a})`
    for (const p of g.paper) {
      sketchPath(ctx, rectPts(p), p.seed + 9.1, step, 1.6, true)
      ctx.stroke()
    }
    const gl = g.level.goal
    ctx.setLineDash([9, 11])
    ctx.strokeStyle = `rgba(255,207,138,${a * 1.25})`
    sketchPath(ctx, rectPts(gl), 42.7, step, 1.8, true)
    ctx.stroke()
    ctx.restore()
  }

  /* ── 石：恒久存在 ── */
  private drawStone(
    ctx: CanvasRenderingContext2D,
    g: Game,
    camX: number,
    step: number,
  ): void {
    for (const r of g.level.stone) {
      if (r.x + r.w < camX - 120 || r.x > camX + VIEW_W + 120) continue
      const seed = hash01(r.x * 0.37) * 50
      ctx.save()
      ctx.fillStyle = C.stoneFill
      sketchPath(ctx, rectPts({ ...r, y: r.y, h: Math.min(r.h, 340) }), seed, step, 1.2, true)
      ctx.fill()
      ctx.lineWidth = 2
      ctx.strokeStyle = C.stoneEdge
      ctx.globalAlpha = 0.85
      ctx.stroke()
      ctx.restore()

      // 地表排线
      ctx.save()
      ctx.globalAlpha = 0.5
      ctx.strokeStyle = C.stoneHatch
      ctx.lineWidth = 1
      hatch(ctx, { x: r.x, y: r.y, w: r.w, h: Math.min(r.h, 90) }, seed + 2.2, step, 17, 1.4, 74)
      ctx.restore()
    }
  }

  /* ── 纸：光的造物 ── */
  private drawPaper(
    ctx: CanvasRenderingContext2D,
    g: Game,
    camX: number,
    t: number,
    step: number,
  ): void {
    for (const p of g.paper) {
      if (p.x + p.w < camX - 120 || p.x > camX + VIEW_W + 120) continue
      const remain = clamp(1 - (t - p.lastLit) / AFTERIMAGE, 0, 1)
      if (!p.lit && remain <= 0) continue
      const solid = p.lit || remain > 0
      if (!solid) continue
      const k = p.lit ? 1 : remain
      const isWall = p.h < 240
      ctx.save()
      ctx.globalAlpha = p.lit ? 1 : 0.28 + k * 0.62

      const fill = p.lit ? C.paperLit : C.after
      const edge = p.lit ? C.paperLitEdge : C.afterEdge
      const hatchCol = p.lit ? C.paperLitHatch : C.afterHatch

      sketchPath(ctx, rectPts(p), p.seed, step, p.lit ? 1.7 : 2.4, true)
      ctx.fillStyle = fill
      ctx.fill()

      ctx.save()
      ctx.globalAlpha *= 0.55
      ctx.strokeStyle = hatchCol
      ctx.lineWidth = 1
      hatch(ctx, p, p.seed + 5.5, step, isWall ? 11 : 15, 1.5, 62)
      ctx.restore()

      ctx.lineWidth = p.lit ? 2.4 : 1.8
      ctx.strokeStyle = edge
      ctx.stroke()

      // 被光照到的瞬间，边缘有一圈暖色
      if (p.lit) {
        ctx.save()
        ctx.globalAlpha = 0.5
        ctx.lineWidth = 5
        ctx.strokeStyle = 'rgba(255,196,110,0.22)'
        ctx.stroke()
        ctx.restore()
      }
      ctx.restore()
    }
  }

  /* ── 蚀 ── */
  private drawEaters(
    ctx: CanvasRenderingContext2D,
    g: Game,
    camX: number,
    t: number,
    step: number,
  ): void {
    for (const e of g.eaters) {
      if (e.x + e.w < camX - 120 || e.x > camX + VIEW_W + 120) continue
      const cx = e.x + e.w / 2
      const baseY = e.y + e.h

      // 黑暗中留下的墨渍（给玩家记忆）
      ctx.save()
      ctx.globalAlpha = 0.34
      ctx.fillStyle = '#000000'
      ctx.beginPath()
      ctx.ellipse(cx, baseY - 3, e.w * 0.62, 7, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()

      const w = e.wake
      if (w <= 0.01) continue
      ctx.save()
      ctx.globalAlpha = Math.min(1, w * 1.3)
      const breathe = 1 + Math.sin(t * 3.1 + e.seed) * 0.05
      const hh = e.h * breathe * (0.85 + w * 0.15)
      const top = baseY - hh

      // 墨块身体
      const body: Pt[] = [
        { x: cx - e.w * 0.5, y: baseY },
        { x: cx - e.w * 0.42, y: top + hh * 0.3 },
        { x: cx - e.w * 0.2, y: top },
        { x: cx + e.w * 0.22, y: top + hh * 0.12 },
        { x: cx + e.w * 0.5, y: top + hh * 0.42 },
        { x: cx + e.w * 0.46, y: baseY },
      ]
      sketchPath(ctx, body, e.seed, step, 2.6, true)
      ctx.fillStyle = C.ink
      ctx.fill()
      ctx.lineWidth = 2
      ctx.strokeStyle = '#2b2118'
      ctx.stroke()

      // 饥饿的眼睛
      const blink = Math.sin(t * 2.2 + e.seed) > -0.86 ? 1 : 0.16
      ctx.fillStyle = C.eye
      for (const s of [-1, 1]) {
        ctx.beginPath()
        ctx.ellipse(cx + s * 8, top + hh * 0.34, 4.6, 2.6 * blink, 0, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.globalAlpha *= 0.25
      ctx.beginPath()
      ctx.ellipse(cx, top + hh * 0.34, 26, 14, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }
  }

  /* ── 逆视者 ── */
  private drawWatchers(
    ctx: CanvasRenderingContext2D,
    g: Game,
    camX: number,
    t: number,
    step: number,
  ): void {
    for (const w of g.watchers) {
      if (w.x + w.w < camX - 160 || w.x > camX + VIEW_W + 160) continue
      const cx = w.x + w.w / 2
      const baseY = w.y + w.h
      const lean = w.frozen ? 0 : Math.sin(t * 9 + w.seed) * 0.07
      const squash = w.frozen ? 0.94 : 1
      ctx.save()

      if (w.frozen) {
        // 被注视：它被压成一张纸，可以穿过
        ctx.globalAlpha = 0.92
        const pts: Pt[] = [
          { x: cx - w.w * 0.52, y: baseY },
          { x: cx - w.w * 0.46, y: baseY - w.h * 0.62 * squash },
          { x: cx - w.w * 0.2, y: baseY - w.h * 0.96 * squash },
          { x: cx + w.w * 0.22, y: baseY - w.h * 0.98 * squash },
          { x: cx + w.w * 0.5, y: baseY - w.h * 0.55 * squash },
          { x: cx + w.w * 0.54, y: baseY },
        ]
        sketchPath(ctx, pts, w.seed, step, 2, true)
        ctx.fillStyle = 'rgba(236,227,207,0.9)'
        ctx.fill()
        ctx.save()
        ctx.globalAlpha *= 0.5
        ctx.strokeStyle = '#3b3529'
        ctx.lineWidth = 1
        hatch(ctx, { x: cx - w.w * 0.55, y: baseY - w.h, w: w.w * 1.1, h: w.h }, w.seed + 3.3, step, 9, 1.2, 78)
        ctx.restore()
        ctx.lineWidth = 2.2
        ctx.strokeStyle = C.coldDeep
        ctx.stroke()
        // 一道冷光的缝
        ctx.beginPath()
        ctx.moveTo(cx - 6, baseY - w.h * 0.78)
        ctx.lineTo(cx + 6, baseY - w.h * 0.78)
        ctx.lineWidth = 2.6
        ctx.strokeStyle = '#5d7387'
        ctx.stroke()
      } else {
        ctx.globalAlpha = 0.62
        const pts: Pt[] = [
          { x: cx - w.w * 0.5, y: baseY },
          { x: cx - w.w * 0.4 + lean * 20, y: baseY - w.h * 0.55 },
          { x: cx - w.w * 0.22 + lean * 26, y: baseY - w.h * 0.86 },
          { x: cx + w.w * 0.2 + lean * 22, y: baseY - w.h * 0.9 },
          { x: cx + w.w * 0.46, y: baseY - w.h * 0.5 },
          { x: cx + w.w * 0.5, y: baseY },
        ]
        sketchPath(ctx, pts, w.seed, step, 2.4, true)
        ctx.fillStyle = 'rgba(16,20,26,0.92)'
        ctx.fill()
        ctx.lineWidth = 1.7
        ctx.strokeStyle = C.cold
        ctx.stroke()
        ctx.beginPath()
        ctx.moveTo(cx - 7, baseY - w.h * 0.74)
        ctx.lineTo(cx + 7, baseY - w.h * 0.74)
        ctx.lineWidth = 2
        ctx.strokeStyle = C.coldDeep
        ctx.stroke()
        // 挪动的拖影
        ctx.globalAlpha = 0.3
        for (let i = 1; i <= 2; i++) {
          ctx.beginPath()
          ctx.moveTo(cx - w.dir * 12 * i, baseY - w.h * (0.2 + 0.12 * i))
          ctx.lineTo(cx - w.dir * (20 + 12 * i), baseY - w.h * (0.24 + 0.12 * i))
          ctx.lineWidth = 1.2
          ctx.stroke()
        }
      }
      ctx.restore()
    }
  }

  /* ── 存档点 ── */
  private drawCheckpoints(
    ctx: CanvasRenderingContext2D,
    g: Game,
    camX: number,
    step: number,
  ): void {
    for (const cp of g.checkpoints) {
      if (cp.x < camX - 80 || cp.x > camX + VIEW_W + 80) continue
      const active = Math.abs(g.respawn.x - cp.x) < 1
      ctx.save()
      ctx.globalAlpha = active ? 0.95 : 0.35
      ctx.strokeStyle = active ? C.warm : C.stoneEdge
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(cp.x, 560)
      ctx.lineTo(cp.x, 522)
      ctx.stroke()
      sketchPath(
        ctx,
        [
          { x: cp.x, y: 522 },
          { x: cp.x + 20, y: 528 },
          { x: cp.x, y: 536 },
        ],
        cp.x * 0.13,
        step,
        1.2,
        true,
      )
      ctx.fillStyle = active ? C.warm : 'transparent'
      ctx.fill()
      ctx.stroke()
      ctx.restore()
    }
  }

  /* ── 门 ── */
  private drawGoal(ctx: CanvasRenderingContext2D, g: Game, t: number, step: number): void {
    const gl = g.level.goal
    const open = 1 - g.doorSeal
    ctx.save()
    // 门框
    ctx.lineWidth = 3
    ctx.strokeStyle = open > 0.5 ? C.warm : C.stoneEdge
    sketchPath(ctx, rectPts(gl), 71.3, step, 2, true)
    ctx.stroke()

    if (gl.requiresDark) {
      // 熄灭之门：被照亮时是砌死的砖，黑暗中才裂开
      ctx.save()
      ctx.globalAlpha = 1 - open
      ctx.strokeStyle = 'rgba(140,132,118,0.9)'
      ctx.lineWidth = 2
      const rows = 4
      for (let r = 0; r < rows; r++) {
        const y = gl.y + (r * gl.h) / rows
        ctx.beginPath()
        ctx.moveTo(gl.x + (r % 2 === 0 ? 0 : 14), y)
        ctx.lineTo(gl.x + gl.w - (r % 2 === 0 ? 14 : 0), y)
        ctx.stroke()
      }
      for (let i = 0; i < gl.w; i += 26) {
        ctx.beginPath()
        ctx.moveTo(gl.x + i, gl.y)
        ctx.lineTo(gl.x + i + 8, gl.y + gl.h)
        ctx.stroke()
      }
      ctx.restore()

      if (open > 0.02) {
        ctx.save()
        ctx.globalCompositeOperation = 'lighter'
        const grad = ctx.createLinearGradient(gl.x, gl.y, gl.x + gl.w, gl.y + gl.h)
        grad.addColorStop(0, `rgba(255,214,150,${0.5 * open})`)
        grad.addColorStop(1, `rgba(255,168,90,${0.18 * open})`)
        ctx.fillStyle = grad
        ctx.fillRect(gl.x, gl.y, gl.w, gl.h)
        ctx.restore()
      }
    } else {
      ctx.save()
      ctx.globalCompositeOperation = 'lighter'
      const pulse = 0.3 + Math.sin(t * 2) * 0.07
      const grad = ctx.createLinearGradient(gl.x, gl.y, gl.x + gl.w, gl.y + gl.h)
      grad.addColorStop(0, `rgba(255,214,150,${pulse})`)
      grad.addColorStop(1, 'rgba(255,168,90,0.06)')
      ctx.fillStyle = grad
      ctx.fillRect(gl.x, gl.y, gl.w, gl.h)
      ctx.restore()
    }
    ctx.restore()
  }

  /* ── 角色 ── */
  private drawChar(ctx: CanvasRenderingContext2D, g: Game, t: number, step: number): void {
    const c = g.char
    const cx = c.x + c.w / 2
    const feet = c.y + c.h
    const moving = c.grounded && !c.blocked
    const phase = c.walk
    const swing = moving ? Math.sin(phase) : 0
    const bob = moving ? Math.abs(Math.sin(phase)) * 1.6 : Math.sin(t * 1.6) * 0.8
    const hy = feet - CHAR_H + bob

    ctx.save()
    ctx.lineWidth = 2.6
    ctx.strokeStyle = C.char
    ctx.lineCap = 'round'

    // 头
    ctx.beginPath()
    ctx.ellipse(cx, hy + 8, 6.4, 6.9, 0, 0, Math.PI * 2)
    ctx.stroke()

    // 躯干
    ctx.beginPath()
    ctx.moveTo(cx, hy + 15)
    ctx.lineTo(cx + swing * 1.2, hy + 31)
    ctx.stroke()

    // 腿
    const legs: Pt[][] = [
      [
        { x: cx + swing * 1.2, y: hy + 31 },
        { x: cx - swing * 7 - 2, y: feet - 1 },
      ],
      [
        { x: cx + swing * 1.2, y: hy + 31 },
        { x: cx + swing * 7 + 2, y: feet - 1 },
      ],
    ]
    for (const l of legs) {
      sketchPath(ctx, l, 5.5, step, 0.9, false)
      ctx.stroke()
    }
    // 手臂
    ctx.beginPath()
    ctx.moveTo(cx, hy + 19)
    ctx.lineTo(cx - swing * 8 + 1, hy + 27)
    ctx.stroke()

    // 落影
    if (c.grounded) {
      ctx.save()
      ctx.globalAlpha = 0.28
      ctx.fillStyle = '#000'
      ctx.beginPath()
      ctx.ellipse(cx, feet + 1, 13, 3.4, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
    }
    ctx.restore()
  }

  private drawParticles(ctx: CanvasRenderingContext2D, g: Game): void {
    ctx.save()
    for (const p of g.particles) {
      const a = clamp(p.life / p.max, 0, 1)
      ctx.globalAlpha = a * 0.9
      ctx.fillStyle = p.tone > 0 ? C.warm : '#d8d2c4'
      ctx.beginPath()
      ctx.arc(p.x, p.y, p.size * (0.4 + a * 0.8), 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
  }

  /* ── 光锥 ── */
  private drawCone(ctx: CanvasRenderingContext2D, g: Game, t: number): void {
    const L = g.light
    if (!L.on) return
    const flick = 1 + Math.sin(t * 6.4) * 0.008 + Math.sin(t * 17.3) * 0.004
    const r = L.radius * flick
    ctx.save()
    ctx.globalCompositeOperation = 'lighter'
    const grad = ctx.createRadialGradient(L.x, L.y, 0, L.x, L.y, r * 1.2)
    grad.addColorStop(0, 'rgba(255,226,175,0.34)')
    grad.addColorStop(0.34, 'rgba(255,203,124,0.19)')
    grad.addColorStop(0.72, 'rgba(255,176,88,0.075)')
    grad.addColorStop(1, 'rgba(255,160,70,0)')
    ctx.fillStyle = grad
    ctx.fillRect(L.x - r * 1.3, L.y - r * 1.3, r * 2.6, r * 2.6)

    const core = ctx.createRadialGradient(L.x, L.y, 0, L.x, L.y, r * 0.36)
    core.addColorStop(0, 'rgba(255,241,212,0.4)')
    core.addColorStop(1, 'rgba(255,220,160,0)')
    ctx.fillStyle = core
    ctx.fillRect(L.x - r * 0.5, L.y - r * 0.5, r, r)

    // 尘埃
    for (let i = 0; i < 26; i++) {
      const d = g.dust(i)
      ctx.globalAlpha = 0.32 * (1 - Math.hypot(d.x - L.x, d.y - L.y) / (r * 1.05))
      ctx.fillStyle = '#ffe6b8'
      ctx.beginPath()
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2)
      ctx.fill()
    }
    ctx.restore()
  }

  /* ── 黑暗（世界坐标系内绘制，渐变中心用世界坐标 L.x / L.y） ── */
  private drawDarkness(ctx: CanvasRenderingContext2D, g: Game, camX: number): void {
    const L = g.light
    // 覆盖当前视口即可（世界坐标）
    const vx = camX - VIEW_W
    const vy = -VIEW_H
    const vw = VIEW_W * 3
    const vh = VIEW_H * 3
    ctx.save()
    if (L.on) {
      const r = L.radius
      const grad = ctx.createRadialGradient(L.x, L.y, r * 0.55, L.x, L.y, r * 2.6)
      grad.addColorStop(0, 'rgba(6,6,8,0)')
      grad.addColorStop(0.45, 'rgba(6,6,8,0.28)')
      grad.addColorStop(1, 'rgba(6,6,8,0.86)')
      ctx.fillStyle = grad
      ctx.fillRect(vx, vy, vw, vh)
    } else {
      const a = g.status === 'won' ? 0.72 : 0.9
      ctx.fillStyle = `rgba(6,6,8,${a})`
      ctx.fillRect(vx, vy, vw, vh)
    }
    ctx.restore()
  }

  private drawGrain(ctx: CanvasRenderingContext2D, g: Game, o: RenderOptions): void {
    const pat = ctx.createPattern(this.noise, 'repeat')
    if (!pat) return
    ctx.save()
    const ox = -((g.t * 37) % 160)
    const oy = -((g.t * 53) % 160)
    ctx.translate(ox, oy)
    ctx.globalAlpha = 0.5 + o.introAlpha * 0.2
    ctx.fillStyle = pat
    ctx.fillRect(0, 0, VIEW_W + 200, VIEW_H + 200)
    ctx.restore()
  }

  private drawVignette(ctx: CanvasRenderingContext2D): void {
    const grad = ctx.createRadialGradient(
      VIEW_W / 2,
      VIEW_H / 2,
      VIEW_H * 0.3,
      VIEW_W / 2,
      VIEW_H / 2,
      VIEW_H * 0.95,
    )
    grad.addColorStop(0, 'rgba(0,0,0,0)')
    grad.addColorStop(1, 'rgba(0,0,0,0.72)')
    ctx.save()
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, VIEW_W, VIEW_H)
    ctx.restore()
  }

  private drawOverlays(ctx: CanvasRenderingContext2D, g: Game, o: RenderOptions): void {
    if (o.showIntroText) {
      ctx.save()
      ctx.globalAlpha = o.introAlpha
      ctx.textAlign = 'center'
      ctx.fillStyle = 'rgba(240,234,220,0.9)'
      ctx.font = '600 44px "Songti SC","Noto Serif SC",serif'
      ctx.fillText(g.level.name, VIEW_W / 2, VIEW_H * 0.38)
      ctx.font = '300 20px "Songti SC","Noto Serif SC",serif'
      ctx.globalAlpha *= 0.7
      ctx.fillText(`第${['一', '二', '三', '四'][g.level.chapter - 1]}章 · ${g.level.chapterName}`, VIEW_W / 2, VIEW_H * 0.38 + 38)
      ctx.globalAlpha = o.introAlpha * 0.55
      ctx.fillText(g.level.intro, VIEW_W / 2, VIEW_H * 0.38 + 78)
      ctx.restore()
    } else if (o.hintWhisper > 0.01) {
      ctx.save()
      ctx.globalAlpha = o.hintWhisper
      ctx.textAlign = 'center'
      ctx.fillStyle = 'rgba(255,214,150,0.92)'
      ctx.font = '600 26px "Songti SC","Noto Serif SC",serif'
      ctx.fillText('熄灭它。', VIEW_W / 2, VIEW_H * 0.3)
      ctx.restore()
    }
    if (g.status === 'dying' && g.deathCause) {
      const p = clamp(1 - g.deathTimer / 1.05, 0, 1)
      const a = p < 0.3 ? p / 0.3 : 1 - (p - 0.3) * 0.25
      const msg =
        g.deathCause === 'abyss'
          ? '她没有踩到任何东西'
          : g.deathCause === 'eaten'
            ? '你照亮了它，它就醒了'
            : '你移开了视线'
      ctx.save()
      ctx.globalAlpha = Math.max(0, a) * 0.9
      ctx.textAlign = 'center'
      ctx.fillStyle = 'rgba(255,180,140,0.92)'
      ctx.font = '400 22px "Noto Serif SC","Songti SC",serif'
      ctx.fillText(msg, VIEW_W / 2, VIEW_H / 2 - 10)
      ctx.restore()
    }
    if (g.flash > 0.01) {
      ctx.save()
      ctx.fillStyle = `rgba(255,236,205,${g.flash * 0.5})`
      ctx.fillRect(0, 0, VIEW_W, VIEW_H)
      ctx.restore()
    }
  }
}
