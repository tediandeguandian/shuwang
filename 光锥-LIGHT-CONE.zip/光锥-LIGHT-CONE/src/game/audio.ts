/**
 * 程序化音频：环境底噪 + 焦点听觉
 * 「只有被照亮的区域才发声」——光束内的噪音/呼吸声随光照强度上升
 */

export class AudioEngine {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private humGain: GainNode | null = null
  private whisperGain: GainNode | null = null
  private breathGain: GainNode | null = null
  private beatTimer = 0
  muted = false

  /** 必须在用户手势中调用 */
  ensure(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume()
      return
    }
    try {
      const Ctor: typeof AudioContext =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
      const ctx = new Ctor()
      this.ctx = ctx
      const master = ctx.createGain()
      master.gain.value = this.muted ? 0 : 0.9
      master.connect(ctx.destination)
      this.master = master

      // ── 环境底噪：两个失谐低频振荡 + 慢速滤波摆动
      const ambGain = ctx.createGain()
      ambGain.gain.value = 0.0
      const lp = ctx.createBiquadFilter()
      lp.type = 'lowpass'
      lp.frequency.value = 320
      lp.Q.value = 0.7
      ambGain.connect(lp)
      lp.connect(master)
      const oscA = ctx.createOscillator()
      oscA.type = 'sine'
      oscA.frequency.value = 55
      const oscB = ctx.createOscillator()
      oscB.type = 'triangle'
      oscB.frequency.value = 82.41
      const ab = ctx.createGain()
      ab.gain.value = 0.5
      oscA.connect(ab)
      oscB.connect(ab)
      ab.connect(ambGain)
      oscA.start()
      oscB.start()
      ambGain.gain.setTargetAtTime(0.07, ctx.currentTime, 3)
      const lfo = ctx.createOscillator()
      lfo.frequency.value = 0.05
      const lfoGain = ctx.createGain()
      lfoGain.gain.value = 120
      lfo.connect(lfoGain)
      lfoGain.connect(lp.frequency)
      lfo.start()

      // ── 光噪：白噪经带通，随光锥开启而出现
      const noise = this.noiseSource(ctx, 2.2)
      const humBp = ctx.createBiquadFilter()
      humBp.type = 'bandpass'
      humBp.frequency.value = 520
      humBp.Q.value = 0.9
      const hum = ctx.createGain()
      hum.gain.value = 0
      noise.connect(humBp)
      humBp.connect(hum)
      hum.connect(master)
      this.humGain = hum

      // ── 低语：蚀苏醒时的刺耳高频
      const noise2 = this.noiseSource(ctx, 2.4)
      const wHp = ctx.createBiquadFilter()
      wHp.type = 'highpass'
      wHp.frequency.value = 2100
      const ww = ctx.createGain()
      ww.gain.value = 0
      noise2.connect(wHp)
      wHp.connect(ww)
      ww.connect(master)
      this.whisperGain = ww

      // ── 呼吸：闭眼时的近距离气息
      const noise3 = this.noiseSource(ctx, 3.1)
      const bLp = ctx.createBiquadFilter()
      bLp.type = 'lowpass'
      bLp.frequency.value = 900
      const br = ctx.createGain()
      br.gain.value = 0
      noise3.connect(bLp)
      bLp.connect(br)
      br.connect(master)
      this.breathGain = br
    } catch {
      this.ctx = null
    }
  }

  private noiseSource(ctx: AudioContext, seconds: number): AudioBufferSourceNode {
    const len = Math.floor(ctx.sampleRate * seconds)
    const buf = ctx.createBuffer(1, len, ctx.sampleRate)
    const d = buf.getChannelData(0)
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1
    const src = ctx.createBufferSource()
    src.buffer = buf
    src.loop = true
    src.start()
    return src
  }

  setMuted(m: boolean): void {
    this.muted = m
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.15)
    }
  }

  /** 每帧调用：把游戏状态映射到声音 */
  update(dt: number, lightOn: boolean, closed: boolean, eaterHeat: number, watcherNear: number): void {
    const ctx = this.ctx
    if (!ctx) return
    const now = ctx.currentTime
    if (this.humGain) this.humGain.gain.setTargetAtTime(lightOn ? 0.05 : 0.0, now, 0.12)
    if (this.whisperGain) this.whisperGain.gain.setTargetAtTime(eaterHeat * 0.045, now, 0.1)
    if (this.breathGain) {
      const target = closed ? 0.05 : 0.0
      this.breathGain.gain.setTargetAtTime(target, now, 0.25)
    }
    // 逆视者心跳
    if (watcherNear > 0.02) {
      this.beatTimer -= dt
      if (this.beatTimer <= 0) {
        this.beatTimer = 1.15 - watcherNear * 0.62
        this.thump(0.05 + watcherNear * 0.22)
      }
    } else {
      this.beatTimer = 0
    }
  }

  private thump(gain: number): void {
    const ctx = this.ctx
    if (!ctx || !this.master) return
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.type = 'sine'
    o.frequency.setValueAtTime(74, t)
    o.frequency.exponentialRampToValueAtTime(38, t + 0.22)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0, t)
    g.gain.linearRampToValueAtTime(gain, t + 0.012)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.34)
    o.connect(g)
    g.connect(this.master)
    o.start(t)
    o.stop(t + 0.4)
  }

  sfx(kind: 'imprint' | 'fall' | 'eaten' | 'touch' | 'goal' | 'open'): void {
    const ctx = this.ctx
    if (!ctx || !this.master) return
    const t = ctx.currentTime
    const g = ctx.createGain()
    g.connect(this.master)
    if (kind === 'imprint') {
      const src = this.noiseSource(ctx, 0.3)
      const bp = ctx.createBiquadFilter()
      bp.type = 'bandpass'
      bp.frequency.setValueAtTime(700, t)
      bp.frequency.linearRampToValueAtTime(2400, t + 0.1)
      bp.Q.value = 3
      g.gain.setValueAtTime(0.0001, t)
      g.gain.linearRampToValueAtTime(0.05, t + 0.008)
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12)
      src.connect(bp)
      bp.connect(g)
      return
    }
    if (kind === 'fall' || kind === 'eaten' || kind === 'touch') {
      const o = ctx.createOscillator()
      o.type = kind === 'fall' ? 'sine' : 'sawtooth'
      const f0 = kind === 'fall' ? 420 : kind === 'eaten' ? 180 : 300
      o.frequency.setValueAtTime(f0, t)
      o.frequency.exponentialRampToValueAtTime(kind === 'fall' ? 58 : 44, t + 0.5)
      const lp = ctx.createBiquadFilter()
      lp.type = 'lowpass'
      lp.frequency.value = kind === 'eaten' ? 900 : 1400
      g.gain.setValueAtTime(0.0001, t)
      g.gain.linearRampToValueAtTime(kind === 'eaten' ? 0.16 : 0.1, t + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6)
      o.connect(lp)
      lp.connect(g)
      o.start(t)
      o.stop(t + 0.7)
      return
    }
    if (kind === 'open') {
      const o = ctx.createOscillator()
      o.type = 'sine'
      o.frequency.setValueAtTime(220, t)
      o.frequency.exponentialRampToValueAtTime(660, t + 0.9)
      g.gain.setValueAtTime(0.0001, t)
      g.gain.linearRampToValueAtTime(0.06, t + 0.3)
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.4)
      o.connect(g)
      o.start(t)
      o.stop(t + 1.5)
      return
    }
    // goal：温暖的和弦
    const freqs = [261.6, 392, 523.3]
    freqs.forEach((f, i) => {
      const o = ctx.createOscillator()
      o.type = 'sine'
      o.frequency.value = f
      const gg = ctx.createGain()
      gg.gain.setValueAtTime(0.0001, t)
      gg.gain.linearRampToValueAtTime(0.05, t + 0.05 + i * 0.08)
      gg.gain.exponentialRampToValueAtTime(0.0001, t + 1.8)
      o.connect(gg)
      gg.connect(this.master!)
      o.start(t)
      o.stop(t + 2)
    })
  }
}

export const audio = new AudioEngine()
