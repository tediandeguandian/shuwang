import type { Progress, Rating } from './types'

const KEY = 'lightcone.save.v1'

export type SaveData = {
  progress: Progress
  muted: boolean
  cleared: boolean
  /** 已经读过开场机制说明的关卡 */
  seenBriefs: string[]
}

const empty = (): SaveData => ({ progress: {}, muted: false, cleared: false, seenBriefs: [] })

export const loadSave = (): SaveData => {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return empty()
    const parsed = JSON.parse(raw) as Partial<SaveData>
    return {
      progress: parsed.progress ?? {},
      muted: parsed.muted ?? false,
      cleared: parsed.cleared ?? false,
      seenBriefs: Array.isArray(parsed.seenBriefs) ? parsed.seenBriefs : [],
    }
  } catch {
    return empty()
  }
}

export const persistSave = (d: SaveData): void => {
  try {
    localStorage.setItem(KEY, JSON.stringify(d))
  } catch {
    /* 忽略隐私模式下的写入失败 */
  }
}

/** par 是「一次合格的注视」的参考光耗 */
export const ratingOf = (cost: number, par: number): Rating => {
  if (cost <= par * 0.72) return 'eclipse'
  if (cost <= par * 1.08) return 'dim'
  return 'faint'
}

export const RATING: Record<Rating, { name: string; desc: string; color: string }> = {
  eclipse: { name: '全蚀', desc: '光只在必须的时候亮——你学会了闭眼', color: '#ffcf8a' },
  dim: { name: '半明', desc: '光的用量恰到好处', color: '#cfc4ac' },
  faint: { name: '微光', desc: '你看见了终点，但光烧得有点多', color: '#8d8676' },
}

export const RATING_ORDER: Rating[] = ['faint', 'dim', 'eclipse']
