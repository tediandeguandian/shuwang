import { LEVELS } from './levels'
import type { Progress } from './types'

export type CodexKey =
  | 'her'
  | 'paper'
  | 'stone'
  | 'wall'
  | 'afterimage'
  | 'eater'
  | 'energy'
  | 'watcher'
  | 'door'

export type CodexKind = 'rule' | 'tool' | 'hazard'

export type CodexEntry = {
  key: CodexKey
  name: string
  latin: string
  tagline: string
  body: string
  kind: CodexKind
}

export const KIND_LABEL: Record<CodexKind, string> = {
  rule: '规则',
  tool: '光的造物',
  hazard: '危险',
}

export const CODEX: Record<CodexKey, CodexEntry> = {
  her: {
    key: 'her',
    name: '余烬',
    latin: 'THE ASH',
    tagline: '她只会向前走',
    body: '你无法操作她。她匀速向前，只有在被实体化的纸墙挡住时才会停下——所以你能做的，只有让她脚下的路先存在。',
    kind: 'rule',
  },
  paper: {
    key: 'paper',
    name: '纸',
    latin: 'PAPER',
    tagline: '光落在哪里，路才在哪里',
    body: '断桥、平台与墙都是纸做的。光锥覆盖时它们实体化；光一离开，它们散回噪点。她踩在还没被确认的纸上，就会掉进虚无。',
    kind: 'tool',
  },
  stone: {
    key: 'stone',
    name: '石',
    latin: 'STONE',
    tagline: '已经发生过的事，不会再变',
    body: '石地永远存在，不需要光。它也是唯一能让你安心闭眼、恢复光能的地方。',
    kind: 'rule',
  },
  wall: {
    key: 'wall',
    name: '纸墙',
    latin: 'PAPER WALL',
    tagline: '光造出路，也筑起墙',
    body: '立在路中间的纸柱。被照亮时她会撞上去停下；想让她通过，就必须把光从它身上移开——哪怕那里看起来正需要光。',
    kind: 'hazard',
  },
  afterimage: {
    key: 'afterimage',
    name: '残影',
    latin: 'AFTERIMAGE',
    tagline: '光走了，纸还记得',
    body: '被照亮过的纸，熄灭后仍会实体化 1.35 秒。真正的高手不把光放在她脚下，而是提前扫过前方的路——脚下靠的是记忆。',
    kind: 'rule',
  },
  eater: {
    key: 'eater',
    name: '蚀',
    latin: 'THE EATER',
    tagline: '别把光照在它身上',
    body: '它睡在石地上，只在被照亮时苏醒，眼里亮起两点橙色。醒着的蚀咬到她，一切就要重来。你要把光停在两枚蚀之间的窄缝里，从它们中间挤过去。',
    kind: 'hazard',
  },
  energy: {
    key: 'energy',
    name: '光能',
    latin: 'THE BREATH',
    tagline: '闭眼是另一种呼吸',
    body: '第三章起光能有限：亮着就消耗，光锥越宽越贵；窄而亮的光最划算。按住空格闭眼，光能才会在黑暗里恢复。闭眼时世界是真的全黑。',
    kind: 'rule',
  },
  watcher: {
    key: 'watcher',
    name: '逆视者',
    latin: 'THE WATCHER',
    tagline: '你不看它，它就朝她走来',
    body: '规则与蚀正好相反：被注视时它被压成一张纸——这时可以让她直接穿过去；你一移开视线，它重新变成实体，并朝她走来。',
    kind: 'hazard',
  },
  door: {
    key: 'door',
    name: '熄灭之门',
    latin: 'THE DARK GATE',
    tagline: '最后一段路，不需要光',
    body: '门只在黑暗里成形：被光照到时，它是一面砌死的砖墙。你必须主动熄灭唯一的光，才能走进去——而她得先走到门前站定。',
    kind: 'rule',
  },
}

/** 图鉴展示顺序 */
export const CODEX_ORDER: CodexKey[] = [
  'her',
  'paper',
  'stone',
  'wall',
  'afterimage',
  'eater',
  'energy',
  'watcher',
  'door',
]

/** 每一关「新登场」的机制：进入该关时弹出说明 */
export const LEVEL_BRIEF: Record<string, CodexKey[]> = {
  c1l1: ['her', 'paper', 'stone'],
  c1l3: ['wall'],
  c2l1: ['eater', 'afterimage'],
  c3l1: ['energy'],
  c3l2: ['watcher'],
  c4l2: ['door'],
}

export const briefEntries = (levelId: string): CodexEntry[] =>
  (LEVEL_BRIEF[levelId] ?? []).map((k) => CODEX[k])

/**
 * 玩家「已经知道的」关卡：读过开场说明，或已经通关。
 * 图鉴与关卡目录的揭示都以它为准——没解锁的章节不会被提前剧透。
 */
export const knownLevelIds = (progress: Progress, seenBriefs: string[]): string[] =>
  LEVELS.filter((l) => seenBriefs.includes(l.id) || !!progress[l.id]).map((l) => l.id)

/** 由已知关卡推导出的图鉴条目 */
export const codexFor = (knownIds: string[]): CodexEntry[] => {
  const set = new Set<CodexKey>()
  for (const id of knownIds) for (const k of LEVEL_BRIEF[id] ?? []) set.add(k)
  return CODEX_ORDER.filter((k) => set.has(k)).map((k) => CODEX[k])
}
