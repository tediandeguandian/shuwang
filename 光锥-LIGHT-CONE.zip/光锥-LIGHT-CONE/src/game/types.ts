export type Rect = { x: number; y: number; w: number; h: number }

export type EaterDef = { x: number; y: number }
export type WatcherDef = { x: number; y: number; speed?: number }

export type GoalDef = {
  x: number
  y: number
  w: number
  h: number
  /** 只有熄灭光锥时，门才存在 */
  requiresDark?: boolean
}

export type EnergyDef = {
  /** 每秒消耗（半径 185 时） */
  drain: number
  /** 闭眼时每秒恢复 */
  refill: number
  /** 初始光能 0~1 */
  start: number
}

export type Level = {
  id: string
  chapter: number
  chapterName: string
  name: string
  hint: string
  intro: string
  outro: string
  width: number
  height: number
  spawn: { x: number; y: number }
  goal: GoalDef
  /** 石：永远存在 */
  stone: Rect[]
  /** 纸：被光照亮才存在（含纸墙） */
  paper: Rect[]
  eaters: EaterDef[]
  watchers: WatcherDef[]
  /** 目标光耗，用于评价 */
  par: number
  /** 开场停顿：显影结束后，她还会站一会儿等你（秒） */
  hold?: number
  /** 有光能上限的关卡 */
  energy?: EnergyDef
}

export type Rating = 'eclipse' | 'dim' | 'faint'

export type LevelRecord = {
  /** 最佳（最低）光耗 */
  cost: number
  time: number
  rating: Rating
}

export type Progress = Record<string, LevelRecord>

export type GameStatus = 'intro' | 'playing' | 'dying' | 'won' | 'paused'

export type PaperState = Rect & {
  lit: boolean
  lastLit: number
  /** 曾被点亮的次数（用于笔触生成） */
  seed: number
}

export type EaterState = {
  x: number
  y: number
  w: number
  h: number
  lit: boolean
  wake: number
  seed: number
}

export type WatcherState = {
  x: number
  y: number
  w: number
  h: number
  dir: number
  speed: number
  frozen: boolean
  seed: number
}

export type DeathCause = 'abyss' | 'eaten' | 'watcher'

export type CharState = {
  x: number
  y: number
  w: number
  h: number
  vy: number
  grounded: boolean
  blocked: boolean
  walk: number
}

export type LightState = {
  x: number
  y: number
  radius: number
  targetRadius: number
  /** 玩家按住空格：闭眼 */
  closed: boolean
  /** 光能耗尽导致的强制熄灭 */
  forcedOff: boolean
  on: boolean
}

export type Particle = {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  max: number
  size: number
  tone: number
}

export type GameEvent =
  | { kind: 'imprint' }
  | { kind: 'wake' }
  | { kind: 'fall' }
  | { kind: 'eaten' }
  | { kind: 'touch' }
  | { kind: 'goal' }
  | { kind: 'open' }

export type Snapshot = {
  status: GameStatus
  time: number
  cost: number
  energy: number
  hasEnergy: boolean
  radius: number
  closed: boolean
  forcedOff: boolean
  levelId: string
  deaths: number
  breathCount: number
}
