/** 手绘炭笔风格绘制工具：所有线条都带低频抖动，模拟逐帧手绘的「沸腾」感 */

export const hash01 = (n: number): number => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453
  return x - Math.floor(x)
}

export const hashXY = (x: number, y: number): number => {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453
  return s - Math.floor(s)
}

/** 手绘沸腾的帧号：每秒 7 次抖动，模仿定格手绘 */
export const boil = (t: number, fps = 7): number => Math.floor(t * fps)

export type Pt = { x: number; y: number }

const jit = (seed: number, i: number, step: number, salt: number, amp: number): number =>
  (hash01(seed * 13.13 + i * 7.71 + step * 101.3 + salt) - 0.5) * 2 * amp

/** 带顶点抖动的手绘折线 */
export function sketchPath(
  ctx: CanvasRenderingContext2D,
  pts: Pt[],
  seed: number,
  step: number,
  amp = 2,
  close = true,
): void {
  const dense: Pt[] = []
  const n = pts.length
  for (let i = 0; i < n; i++) {
    const a = pts[i]
    const b = pts[(i + 1) % n]
    const d = Math.hypot(b.x - a.x, b.y - a.y)
    const div = Math.max(1, Math.min(7, Math.round(d / 80)))
    for (let k = 0; k < div; k++) {
      const u = k / div
      dense.push({ x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * u })
    }
  }
  ctx.beginPath()
  for (let i = 0; i < dense.length; i++) {
    const p = dense[i]
    const px = p.x + jit(seed, i, step, 1.7, amp)
    const py = p.y + jit(seed, i, step, 9.3, amp)
    if (i === 0) ctx.moveTo(px, py)
    else ctx.lineTo(px, py)
  }
  if (close) ctx.closePath()
}

export const rectPts = (r: { x: number; y: number; w: number; h: number }): Pt[] => [
  { x: r.x, y: r.y },
  { x: r.x + r.w, y: r.y },
  { x: r.x + r.w, y: r.y + r.h },
  { x: r.x, y: r.y + r.h },
]

/** 在矩形内画排线（阴影），线条本身也带抖动 */
export function hatch(
  ctx: CanvasRenderingContext2D,
  r: { x: number; y: number; w: number; h: number },
  seed: number,
  step: number,
  spacing = 13,
  amp = 1.6,
  angleDeg = 62,
): void {
  if (r.w < 2 || r.h < 2) return
  ctx.save()
  ctx.beginPath()
  sketchPath(ctx, rectPts(r), seed + 4.4, step, 0.6, true)
  ctx.clip()
  const ang = (angleDeg * Math.PI) / 180
  const dx = Math.cos(ang)
  const dy = Math.sin(ang)
  const diag = Math.hypot(r.w, r.h)
  const cx = r.x + r.w / 2
  const cy = r.y + r.h / 2
  const count = Math.ceil(diag / spacing) + 2
  ctx.beginPath()
  for (let i = 0; i <= count; i++) {
    const off = (i - count / 2) * spacing
    const ox = cx - dx * off
    const oy = cy - dy * off
    const wob = jit(seed, i, step, 21.5, amp)
    ctx.moveTo(ox - dy * diag * 0.5 + wob, oy + dx * diag * 0.5)
    ctx.lineTo(ox + dy * diag * 0.5 + wob, oy - dx * diag * 0.5)
  }
  ctx.stroke()
  ctx.restore()
}

/** 生成一张噪点纹理，用于纸张颗粒与胶片噪点 */
export function makeNoiseTile(size = 160, alpha = 26): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = size
  c.height = size
  const g = c.getContext('2d')
  if (!g) return c
  const img = g.createImageData(size, size)
  for (let i = 0; i < size * size; i++) {
    const v = Math.random()
    img.data[i * 4] = 235
    img.data[i * 4 + 1] = 232
    img.data[i * 4 + 2] = 222
    img.data[i * 4 + 3] = v * alpha
  }
  g.putImageData(img, 0, 0)
  return c
}

/** 纸张纤维：细密的短横线 */
export function makeFiberTile(size = 220): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = size
  c.height = size
  const g = c.getContext('2d')
  if (!g) return c
  g.strokeStyle = 'rgba(240,236,226,0.05)'
  g.lineWidth = 1
  for (let i = 0; i < 240; i++) {
    const x = Math.random() * size
    const y = Math.random() * size
    const l = 4 + Math.random() * 22
    g.beginPath()
    g.moveTo(x, y)
    g.lineTo(x + l, y + (Math.random() - 0.5) * 3)
    g.stroke()
  }
  return c
}

export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t

export const clamp = (v: number, lo: number, hi: number): number => (v < lo ? lo : v > hi ? hi : v)

export const easeInOut = (t: number): number => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2)
