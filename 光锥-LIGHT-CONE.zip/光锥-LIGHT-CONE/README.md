# 《光锥》LIGHT CONE

> 一款“唯一动词是**看**”的观察者效应解谜游戏。
> 你不能移动她、不能攻击、不能跳跃——只能决定光落在哪里。
> **被照亮的地方才存在；你移开视线，它就消失。**

本目录是**只包含游戏本身**的完整可运行工程（已剔除脚手架里用不到的 54 个 UI 组件与全部示例文件）。

## 运行

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # 产物在 dist/
npm run preview    # 预览构建产物
```

要求 Node 20.19+ / 22+。

## 核心机制

| 规则 | 说明 |
|---|---|
| **纸 / 石** | 「石」永远存在；「纸」（桥、墙）只有被光锥覆盖时才实体化 |
| **残影** | 被照亮过的纸，熄灭后仍会撑 **1.35 秒**——高手把光放在前方，脚下靠的是记忆 |
| **她只会往前走** | 角色自动前进，被实体化的纸墙挡住才会停；你不会操作她 |
| **蚀** | 睡在石地上，**被照亮才苏醒并咬人**。要在两枚蚀之间的窄缝里用光 |
| **逆视者** | 规则相反：被注视时被压成一张纸（可以穿过），一移开视线就变成实体并走近 |
| **光能 / 呼吸** | 第三、四章有光能上限；按住空格闭眼，光能才在黑暗里恢复 |
| **熄灭之门** | 终章的门只在黑暗里成形，必须主动熄灯才能走进去 |

## 操作

| 操作 | 效果 |
|---|---|
| 鼠标移动 / `WASD` / 方向键 | 移动光锥 |
| 滚轮 / `Q` `E` | 调焦：窄而亮（便宜、精准）或宽而暗（贵、覆盖广） |
| 按住 `空格` | 闭眼：光锥熄灭，恢复光能；也可跳过开场 |
| 按住 `Tab` | 蓝图：看见整关的草图 |
| `Esc` / `P` · `R` | 暂停 · 重来本关 |

## 评价

`光耗 = ∫(半径/185)² dt`，只在光锥开启时累加（闭眼不花钱）。
每关有参考值 `par`：**全蚀** ≤ 0.72·par、**半明** ≤ 1.08·par、其余为**微光**。
进度与已读说明存在 localStorage（`lightcone.save.v1`）。

## 目录结构

```
index.html                    入口
package.json  vite.config.ts  tailwind.config.js  postcss.config.js  tsconfig*.json
src/
  main.tsx                    React 挂载
  App.tsx                     页面状态机（标题 / 说明 / 目录 / 游戏）
  index.css                   主题变量 + 全部 lc-* 自定义样式
  App.css                     #root 布局重置
  game/                       ── 游戏内核（纯 TS，零 React）──
    types.ts                  类型定义
    levels.ts                 4 章 10 关数据
    engine.ts                 核心模拟：光照实体化 / 残影 / 光能 / 碰撞 / 判定 / 镜头
    render.ts                 炭笔渲染器：沸腾线 / 排线 / 体积光 / 黑暗层 / 颗粒
    sketch.ts                 手绘绘制原语（抖动线、排线、噪点与纤维纹理）
    palette.ts                调色板
    codex.ts                  机制词条 + 各关「新登场」映射
    audio.ts                  Web Audio 程序化音效 + 焦点听觉
    storage.ts                存档与评价
  components/                 ── 界面层（React）──
    GameStage.tsx             canvas 主循环 + HUD + 暂停/结算 + 图鉴
    TitleScreen.tsx           标题页
    HeroCanvas.tsx            标题页的可交互演示画布
    HowToPlay.tsx             玩法说明（按进度揭示）
    LevelSelect.tsx           关卡目录
    CodexOverlay.tsx          图鉴 / 章节说明弹窗
    CodexGlyph.tsx            9 张手绘动态机制图标
    ui/button.tsx             唯一用到的 shadcn 组件
  lib/utils.ts                cn() 工具（button 依赖）
```

## 架构说明

`game/` 与 `components/` 完全解耦：

- `engine.ts` 不依赖 DOM，接收每帧的 `dt` 与指针/按键输入，输出状态；可在 Node 中直接跑（关卡可通关性、光点跟随精度都是用这种方式验证的）。
- `render.ts` 只读 `Game` 状态并绘制，不修改它。
- `GameStage.tsx` 负责 `requestAnimationFrame` 循环、把输入喂给引擎、把状态同步给 HUD。

坐标系约定：**光锥的瞄准点在引擎内以「屏幕坐标」保存**，每帧再换算成世界坐标；
绘制光锥与黑暗层时必须处在世界变换内（`ctx.translate(-camX, …)`），否则会重复叠加镜头偏移。
